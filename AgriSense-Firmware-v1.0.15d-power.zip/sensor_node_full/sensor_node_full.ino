// Sensor Node - full sketch
// DHT22 + capacitive soil moisture + MQ135 + DS3231 RTC + micro SD logging
// Board: ESP32 Dev Module (ESP32 WROOM-32 devkit on the expansion board)
// Libraries to install: "DHT sensor library" (Adafruit), "Adafruit Unified Sensor",
//                       "RTClib" (Adafruit). SPI, Wire and SD come with the ESP32 core.
//
// Wiring (expansion board pin names):
//   DHT22 (3-pin module)  OUT -> D32 (S),  + -> V,  - -> G   (V pins on 3.3V)
//   Soil moisture         AOUT -> D34 (S), VCC -> V, GND -> G
//   MQ135                 AO -> 10k + 10k divider -> D35 (S); VCC -> 5V; GND -> GND
//   DS3231 mini RTC       + -> 3.3V, D (SDA) -> D21, C (SCL) -> D22, last pin -> GND
//   SD module (MLE00157)  CS -> D5, SCK -> D18, MOSI -> D23,
//                         MISO (printed "MOSO") -> D19, VCC -> 5V, GND -> GND

#include <Wire.h>
#include <SPI.h>
#include <SD.h>
#include "RTClib.h"
#include "DHT.h"
#include <WiFi.h>
#include <WebServer.h>
#include <esp_system.h>
#include <Preferences.h>
#include "demo_network.h"
DemoNetwork network("sensor");

// Default only. Later assignments come from the app and survive restarts.
String sensorCrop = "tomato";
String deviceId;
String pairingCode;
Preferences preferences;
bool configurationReady = false;
bool disableAutomaticCapture();
bool clearWarnings();
// Set true only after measuring and replacing DRY_VALUE and WET_VALUE.
const bool SOIL_CALIBRATED = false;
WebServer server(80);
String latestJson;
String bootId;
unsigned long sampleSequence = 0;
unsigned long sampleMillis = 0;
unsigned long lastLog = 0;
unsigned long lastSample = 0, dhtSampleMillis = 0;
bool dhtSampled = false;
float latestTemperature = NAN, latestHumidity = NAN;
int latestSoilRaw = 0, latestGasRaw = 0, latestSoilPercent = 0;

bool validCrop(const String &crop) {
  return crop == "tomato" || crop == "chili" || crop == "eggplant";
}

bool validPairingCode(const String &code) {
  if (code.length() != 32) return false;
  for (size_t i = 0; i < code.length(); i++) {
    if (!((code[i] >= '0' && code[i] <= '9') || (code[i] >= 'a' && code[i] <= 'f'))) return false;
  }
  return true;
}

void initializeConfiguration() {
  if (!preferences.begin("agrisense", false)) return;
  sensorCrop = preferences.getString("crop", "tomato");
  if (!validCrop(sensorCrop)) sensorCrop = "tomato";
  if (preferences.getString("crop", "") != sensorCrop &&
      preferences.putString("crop", sensorCrop) != sensorCrop.length()) return;
  pairingCode = preferences.getString("pairing", "");
  if (!validPairingCode(pairingCode)) {
    // Offline logging still restores the crop, but do not create a key without
    // the Wi-Fi entropy source enabled. HTTP is disabled in this case anyway.
    if (strlen(AGRISENSE_WIFI_SSID) == 0) return;
    // Wi-Fi is running before this call, supplying entropy to the ESP32 RNG.
    uint8_t randomBytes[16];
    esp_fill_random(randomBytes, sizeof(randomBytes));
    char encoded[33];
    for (int i = 0; i < 16; i++) snprintf(encoded + i * 2, 3, "%02x", randomBytes[i]);
    pairingCode = String(encoded);
    if (preferences.putString("pairing", pairingCode) != pairingCode.length()) return;
  }
  configurationReady = true;
  Serial.print("Sensor device ID: ");
  Serial.println(deviceId);
  // Existing private pairing key stays in NVS and is not advertised or logged.
  Serial.print("Saved crop: ");
  Serial.println(sensorCrop);
}

void serveConfiguration() {
  server.sendHeader("Cache-Control", "no-store");
  if (!configurationReady) {
    server.send(503, "application/json", "{\"error\":\"configuration_storage_unavailable\"}");
    return;
  }
  server.send(200, "application/json", "{\"crop_protocol\":1,\"device_id\":\"" +
    deviceId + "\",\"crop\":\"" + sensorCrop + "\"}");
}

void changeCrop() {
  server.sendHeader("Cache-Control", "no-store");
  if (!configurationReady) {
    server.send(503, "application/json", "{\"error\":\"configuration_storage_unavailable\"}");
    return;
  }
  const String offered = server.header("X-AgriSense-Key");
  uint8_t difference = 0;
  if (offered.length() == pairingCode.length()) {
    for (size_t i = 0; i < pairingCode.length(); i++) difference |= offered[i] ^ pairingCode[i];
  } else {
    difference = 1;
  }
  if (difference != 0) {
    server.send(401, "application/json", "{\"error\":\"pairing_required\"}");
    return;
  }
  if (server.args() != 2 || !server.hasArg("crop") || !server.hasArg("device_id") ||
      !validCrop(server.arg("crop"))) {
    server.send(400, "application/json", "{\"error\":\"invalid_crop_request\"}");
    return;
  }
  if (server.arg("device_id") != deviceId) {
    server.send(409, "application/json", "{\"error\":\"wrong_device\"}");
    return;
  }
  const String requested = server.arg("crop");
  if (requested != sensorCrop) {
    // Never carry another crop's automatic rules across reassignment.
    if (!disableAutomaticCapture() || !clearWarnings()) {
      configurationReady = false;
      server.send(503, "application/json", "{\"error\":\"save_failed_restart_sensor\"}");
      return;
    }
    if (preferences.putString("crop", requested) != requested.length() ||
        preferences.getString("crop", "") != requested) {
      configurationReady = false;
      server.send(503, "application/json", "{\"error\":\"save_failed_restart_sensor\"}");
      return;
    }
    sensorCrop = requested;
    latestJson = "";  // Never re-label a cached reading from the previous plant.
    lastLog = 0;      // The next loop takes a fresh sample with a new ID.
    lastSample = 0;
  }
  serveConfiguration();
}

void serveReadings() {
  server.sendHeader("Cache-Control", "no-store");
  if (!configurationReady) {
    server.send(503, "application/json", "{\"error\":\"configuration_storage_unavailable\"}");
    return;
  }
  if (latestJson.length() == 0 || millis() - sampleMillis > 30000) {
    server.send(503, "application/json", "{\"error\":\"no_fresh_sample\"}");
    return;
  }
  server.send(200, "application/json", latestJson +
    ",\"dht_age_ms\":" + String(dhtSampled ? millis() - dhtSampleMillis : 60000UL) +
    ",\"age_ms\":" + String(millis() - sampleMillis) + "}");
}

// ---- Pins ----
#define DHT_PIN    32
#define SOIL_PIN   34
#define MQ135_PIN  35
#define SD_CS      5
#define I2C_SDA    21
#define I2C_SCL    22

// ---- Soil calibration: REPLACE with your own readings ----
// DRY_VALUE = raw reading in dry air, WET_VALUE = raw reading with the
// sensor tip in water (up to the line). These are placeholders, so the
// soil percentage means nothing until you replace them.
const int DRY_VALUE = 3000;
const int WET_VALUE = 1200;

// ---- Logging ----
const unsigned long LOG_INTERVAL_MS = 10000;      // SD/serial logging only
const unsigned long SAMPLE_INTERVAL_MS = 1000, DHT_INTERVAL_MS = 2000;
const char *LOG_FILE = "/sensor_log_v2.csv";

// Set to 1 for ONE upload to force the RTC to the computer's time,
// then set back to 0 and upload again.
#define FORCE_SET_RTC 0

DHT dht(DHT_PIN, DHT22);
RTC_DS3231 rtc;

bool rtcOk = false;
bool sdOk = false;

#include "auto_capture.h"
#include "warning_config.h"
#include "demo_controls.h"

void setup() {
  Serial.begin(115200);
  delay(1000);
  Serial.println("Sensor Node starting");

  const uint64_t mac = ESP.getEfuseMac();
  char id[13];
  snprintf(id, sizeof(id), "%04x%08lx", (unsigned int)(mac >> 32), (unsigned long)(mac & 0xffffffff));
  deviceId = String(id);
  network.begin();
  {
    const char *headers[] = {"X-AgriSense-Key"};
    server.collectHeaders(headers, 1);
    server.on("/readings", HTTP_GET, serveReadings);
    server.on("/identity", HTTP_GET, []() {
      server.sendHeader("Cache-Control", "no-store");
      const bool ready = configurationReady && latestJson.length() > 0 && millis() - sampleMillis <= 30000;
      server.send(200, "application/json", demoIdentity("sensor", ready,
        servosReady ? "[\"readings\",\"sd_optional\",\"pan_tilt_v1\",\"app_status_v1\",\"warning_leds_v1\"]" :
          "[\"readings\",\"sd_optional\",\"app_status_v1\",\"warning_leds_v1\"]", sensorCrop));
    });
    server.on("/pan-tilt", HTTP_POST, movePanTilt);
    server.on("/app-status", HTTP_POST, receiveAppStatus);
    server.on("/config", HTTP_GET, serveConfiguration);
    server.on("/crop", HTTP_POST, changeCrop);
    server.on("/automation", HTTP_GET, serveAutomaticCapture);
    server.on("/automation", HTTP_POST, changeAutomaticCapture);
    server.on("/warnings", HTTP_GET, serveWarnings);
    server.on("/warnings", HTTP_POST, changeWarnings);
    server.begin();
  }
  initializeConfiguration();
  if (configurationReady) loadAutomaticCapture();
  if (configurationReady) loadWarnings();
  bootId = deviceId + "-" + String(esp_random(), HEX);

  dht.begin();

  // RTC
  Wire.begin(I2C_SDA, I2C_SCL);
  Wire.setTimeOut(50);
  if (rtc.begin()) {
    rtcOk = true;
    if (FORCE_SET_RTC || rtc.lostPower()) {
      rtc.adjust(DateTime(F(__DATE__), F(__TIME__)));
      Serial.println("RTC time set to the compile time");
    }
    Serial.println("RTC OK");
  } else {
    Serial.println("RTC not found - check SDA/SCL/power wiring");
  }

  // SD card
  if (SD.begin(SD_CS)) {
    sdOk = true;
    if (!SD.exists(LOG_FILE)) {
      File f = SD.open(LOG_FILE, FILE_WRITE);
      if (f) {
        f.println("timestamp,crop,temp_c,humidity_pct,soil_raw,soil_pct,gas_raw");
        f.close();
      }
    }
    Serial.println("SD card OK");
  } else {
    Serial.println("SD init FAILED - check wiring, 5V power, card format");
  }
  // RTC/SD initialization finishes before commanding either servo.
  beginDemoControls();
}

void loop() {
  tickDemoControls();
  network.tick(!servoPowerBusy());
  servoRadioBusy = network.connecting();
  server.handleClient();
  // Sampling and logging have independent schedules; no delay() in this loop.
  if (lastSample != 0 && millis() - lastSample < SAMPLE_INTERVAL_MS) return;
  lastSample = millis();

  // Read the sensors
  if (!dhtSampled || millis() - dhtSampleMillis >= DHT_INTERVAL_MS) {
    latestHumidity = dht.readHumidity();
    latestTemperature = dht.readTemperature();
    if (!isfinite(latestTemperature) || latestTemperature < -40 || latestTemperature > 80) latestTemperature = NAN;
    if (!isfinite(latestHumidity) || latestHumidity < 0 || latestHumidity > 100) latestHumidity = NAN;
    dhtSampleMillis = millis();
    dhtSampled = true;
  }
  const bool dhtFresh = dhtSampled && millis() - dhtSampleMillis <= 5000;
  float humidity = dhtFresh ? latestHumidity : NAN;
  float temperature = dhtFresh ? latestTemperature : NAN;
  int soilRaw       = analogRead(SOIL_PIN);
  const bool soilCalibrated = SOIL_CALIBRATED && DRY_VALUE != WET_VALUE;
  int soilPercent = soilCalibrated ? constrain(map(soilRaw, DRY_VALUE, WET_VALUE, 0, 100), 0, 100) : 0;
  int gasRaw        = analogRead(MQ135_PIN);   // after the divider, roughly half the sensor's output
  latestSoilRaw = soilRaw;
  latestGasRaw = gasRaw;
  latestSoilPercent = soilPercent;

  dhtValid = isfinite(temperature) && temperature >= -40 && temperature <= 80 &&
    isfinite(humidity) && humidity >= 0 && humidity <= 100;
  sampleMillis = millis();
  sampleSequence++;
  tickDemoControls();
  // Failed DHT readings are null, never fabricated zeroes. The app timestamps
  // receipt and uses boot + sequence to avoid duplicate saved samples.
  latestJson = "{\"version\":1,\"device_id\":\"" + deviceId + "\",\"crop\":\"" + sensorCrop +
    "\",\"sample_id\":\"" + bootId + "-" + String(sampleSequence) + "\"" +
    ",\"temp_c\":" + (!isfinite(temperature) || temperature < -40 || temperature > 80 ? String("null") : String(temperature, 1)) +
    ",\"humidity_pct\":" + (!isfinite(humidity) || humidity < 0 || humidity > 100 ? String("null") : String(humidity, 1)) +
    ",\"soil_raw\":" + String(soilRaw) +
    ",\"soil_pct\":" + (soilCalibrated ? String(soilPercent) : String("null")) +
    ",\"soil_calibrated\":" + (soilCalibrated ? String("true") : String("false")) +
    ",\"gas_raw\":" + String(gasRaw);

  // Timestamp from the RTC
  evaluateAutomaticCapture(temperature, humidity, soilCalibrated ? (float)soilPercent : NAN, !servoPowerBusy());

  // Keep sampling/alert timing active, but defer local SD load until motion settles.
  if (servoPowerBusy()) return;
  if (lastLog != 0 && millis() - lastLog < LOG_INTERVAL_MS) return;
  lastLog = millis();

  // Timestamp from the RTC
  char ts[20] = "NO_RTC";
  if (rtcOk) {
    DateTime now = rtc.now();
    snprintf(ts, sizeof(ts), "%04d-%02d-%02d %02d:%02d:%02d",
             now.year(), now.month(), now.day(),
             now.hour(), now.minute(), now.second());
  }

  // Build one CSV line (the DHT fields are left empty if it failed to read)
  char line[192];
  const String temperatureText = isnan(temperature) ? "" : String(temperature, 1);
  const String humidityText = isnan(humidity) ? "" : String(humidity, 1);
  const String soilText = soilCalibrated ? String(soilPercent) : "";
  if (isnan(humidity) || isnan(temperature)) {
    Serial.println("DHT read failed - check wiring");
  }
  snprintf(line, sizeof(line), "%s,%s,%s,%s,%d,%s,%d", ts, sensorCrop.c_str(),
    temperatureText.c_str(), humidityText.c_str(), soilRaw, soilText.c_str(), gasRaw);
  Serial.println(line);

  // Save to the SD card
  if (sdOk) {
    File f = SD.open(LOG_FILE, FILE_APPEND);
    if (f) {
      if (f.println(line) == 0) sdOk = false;
      f.close();
    } else {
      sdOk = false; // Do not repeatedly stall sampling on an unavailable card.
      Serial.println("Could not open the log file");
    }
  }
}
