"""Run firmware scheduling/protocol checks without an ESP32 or private settings."""
from pathlib import Path
import shutil
import subprocess


def main():
    checks = Path(__file__).resolve().parent
    root = checks.parents[2]
    output = root / "output" / "firmware-v15d-power"
    output.mkdir(parents=True, exist_ok=True)
    compiler = shutil.which("g++")
    if compiler is None:
        raise SystemExit("g++ is required; no compiler was installed by this script.")
    cases = [
        ("demo_controls_test", "demo_controls_test.cpp", [], checks),
        ("warning_config_test", "warning_config_test.cpp", [], checks),
        ("network_test", "network_test.cpp", [], checks / "network"),
        ("network_empty_test", "network_test.cpp", ["-DNETWORK_EMPTY_TEST"], checks / "network"),
        ("power_timing_test", "power_timing_test.cpp", [], checks),
    ]
    log = []
    for name, source, flags, includes in cases:
        executable = output / (name + ".exe")
        commands = [
            [compiler, "-std=c++17", "-Wall", "-Wextra", *flags, "-I", str(includes),
             str(checks / source), "-o", str(executable)],
            [str(executable)],
        ]
        for command in commands:
            result = subprocess.run(command, cwd=root, text=True, capture_output=True, check=False)
            log.extend([repr(command), result.stdout, result.stderr, f"Exit: {result.returncode}\n"])
            (output / "host-checks.log").write_text("\n".join(log), encoding="utf-8")
            if result.returncode:
                raise SystemExit(f"FAIL: {name}; see output/firmware-v15d-power/host-checks.log")
        print(f"PASS: {name}")


if __name__ == "__main__":
    main()
