// Host-only test shim. Never part of the Arduino sketch include path.
#pragma once
#include <algorithm>
#include <cassert>
#include <cstdint>
#include <cstdlib>
#include <map>
#include <string>
#include <sstream>
#include <iomanip>
class String {
 public:
  std::string value;
  String() = default;
  String(const char *s) : value(s) {}
  String(std::string s) : value(s) {}
  String(int n) : value(std::to_string(n)) {}
  String(float n, int decimals) { std::ostringstream out; out << std::fixed << std::setprecision(decimals) << n; value = out.str(); }
  size_t length() const { return value.size(); }
  const char *c_str() const { return value.c_str(); }
  char operator[](size_t i) const { return value.at(i); }
  int indexOf(char c) const { auto i = value.find(c); return i == std::string::npos ? -1 : int(i); }
  String substring(size_t start) const { return value.substr(start); }
  String substring(size_t start, size_t end) const { return value.substr(start, end-start); }
  friend String operator+(const String &a, const String &b) { return a.value + b.value; }
  String &operator+=(const String &other) { value += other.value; return *this; }
  friend bool operator==(const String &a, const String &b) { return a.value == b.value; }
  friend bool operator!=(const String &a, const String &b) { return !(a == b); }
};
constexpr int HIGH = 1, LOW = 0, OUTPUT = 1, WL_CONNECTED = 3;
inline uint32_t testMillis = 0;
inline std::map<int, int> levels;
inline std::map<int, uint32_t> duties;
inline bool attachOk = true;
inline uint32_t millis() { return testMillis; }
inline void pinMode(int, int) {}
inline void digitalWrite(int pin, int value) { levels[pin] = value; }
inline bool ledcAttach(int, int hz, int bits) { assert(hz == 50 && bits == 16); return attachOk; }
inline void ledcDetach(int) {}
inline void ledcWrite(int pin, uint32_t duty) { duties[pin] = duty; }
inline int constrain(int n, int low, int high) { return std::clamp(n, low, high); }
struct IPAddress {
  uint32_t value = 0;
  IPAddress() = default;
  IPAddress(int a, int b, int c, int d) : value((uint32_t(a)<<24) | (b<<16) | (c<<8) | d) {}
  bool operator==(const IPAddress &other) const { return value == other.value; }
  bool operator!=(const IPAddress &other) const { return !(*this == other); }
};
constexpr int WIFI_OFF = 0, WIFI_STA = 1, ARDUINO_EVENT_WIFI_STA_DISCONNECTED = 5;
using WiFiEvent_t = int;
struct WiFiEventInfo_t { struct { unsigned reason = 0; } wifi_sta_disconnected; };
inline struct FakeWiFi {
  int state = WL_CONNECTED, begins = 0, stops = 0;
  bool stopOk = true, startOk = true;
  IPAddress ip;
  int status() const { return state; }
  IPAddress localIP() const { return ip; }
  bool mode(int mode) {
    if (mode == WIFI_OFF) { ++stops; if (!stopOk) return false; state = 0; ip = {}; }
    return mode == WIFI_OFF || startOk;
  }
  void setHostname(const char *) {}
  void setAutoReconnect(bool enabled) { assert(!enabled); }
  void setSleep(bool) {}
  template<class Callback> void onEvent(Callback, int) {}
  void begin(const char *, const char *) { ++begins; }
} WiFi;
inline struct FakeServer {
  std::map<std::string, String> fields;
  int status = 0;
  String response;
  void sendHeader(const char *, const char *) {}
  String arg(const char *key) const { auto it = fields.find(key); return it == fields.end() ? String("") : it->second; }
  String arg(const String &key) const { return arg(key.c_str()); }
  int args() const { return int(fields.size()); }
  void send(int code, const char *, const String &body) { status = code; response = body; }
} server;
inline bool configurationReady = true;
inline String deviceId = "aabbccddeeff";
inline unsigned long sampleSequence = 1, sampleMillis = 0;
