#pragma once
#include <HTTPClient.h>
#include <math.h>
#include "auto_capture_timing.h"

struct AutoCaptureConfig {
  uint32_t version = 1;
  bool enabled = false;
  bool selected[3] = {false, false, false};
  float minimum[3] = {-40, 0, 0};
  float maximum[3] = {80, 100, 100};
  uint32_t duration = 30, cooldown = 300;
  char crop[12] = "tomato";
  char camera[16] = "";
  char cameraId[13] = "";
  char cameraKey[33] = "";
};
AutoCaptureConfig automatic;
AutoCaptureTiming automaticTiming;
String autoStatus = "idle";

bool autoHex(const char *s, size_t length) {
  for (size_t i = 0; i < length; ++i)
    if (!((s[i] >= '0' && s[i] <= '9') || (s[i] >= 'a' && s[i] <= 'f'))) return false;
  return s[length] == '\0';
}
bool privateCamera(const String &value) {
  IPAddress ip;
  if (!ip.fromString(value) || ip.toString() != value) return false;
  return ip[0] == 10 || (ip[0] == 172 && ip[1] >= 16 && ip[1] <= 31) ||
    (ip[0] == 192 && ip[1] == 168);
}
bool validAutomatic(const AutoCaptureConfig &c) {
  if (c.version != 1 || c.crop[11] || c.camera[15] || c.cameraId[12] || c.cameraKey[32] ||
      !validCrop(String(c.crop)) || c.duration < 10 || c.duration > 3600 ||
      c.cooldown < 60 || c.cooldown > 86400) return false;
  for (int i = 0; i < 3; ++i) {
    if (!isfinite(c.minimum[i]) || !isfinite(c.maximum[i]) || c.minimum[i] >= c.maximum[i] ||
        c.minimum[i] < (i == 0 ? -40 : 0) || c.maximum[i] > (i == 0 ? 80 : 100)) return false;
  }
  return !c.enabled || ((c.selected[0] || c.selected[1] || c.selected[2]) &&
    privateCamera(String(c.camera)) && autoHex(c.cameraId, 12) && autoHex(c.cameraKey, 32));
}
void resetAutomaticTimers() {
  automaticTiming.reset(millis());
}
bool persistAutomatic(const AutoCaptureConfig &next) {
  if (preferences.putBytes("auto_capture", &next, sizeof(next)) != sizeof(next)) return false;
  AutoCaptureConfig check;
  if (preferences.getBytes("auto_capture", &check, sizeof(check)) != sizeof(check) ||
      memcmp(&check, &next, sizeof(next)) != 0) return false;
  automatic = next;
  resetAutomaticTimers();
  autoStatus = "idle";
  return true;
}
bool disableAutomaticCapture() {
  AutoCaptureConfig next = automatic;
  next.enabled = false;
  automatic.enabled = false; // Fail closed even if flash storage fails.
  return persistAutomatic(next);
}
void loadAutomaticCapture() {
  AutoCaptureConfig loaded;
  if (preferences.getBytesLength("auto_capture") == sizeof(loaded) &&
      preferences.getBytes("auto_capture", &loaded, sizeof(loaded)) == sizeof(loaded) &&
      validAutomatic(loaded) && String(loaded.crop) == sensorCrop) automatic = loaded;
  // A later firmware upload may remove soil calibration. Disable persisted rules
  // rather than exposing an enabled configuration the app cannot safely edit.
  if (automatic.enabled && automatic.selected[2] && !(SOIL_CALIBRATED && DRY_VALUE != WET_VALUE)) {
    if (!disableAutomaticCapture()) configurationReady = false;
  }
  resetAutomaticTimers();
}
bool authorizeAutomatic() {
  server.sendHeader("Cache-Control", "no-store");
  if (!configurationReady) {
    server.send(503, "application/json", "{\"error\":\"configuration_storage_unavailable\"}");
    return false;
  }
  String offered = server.header("X-AgriSense-Key");
  uint8_t diff = offered.length() == 32 ? 0 : 1;
  if (!diff) for (int i = 0; i < 32; ++i) diff |= offered[i] ^ pairingCode[i];
  if (diff) server.send(401, "application/json", "{\"error\":\"pairing_required\"}");
  return diff == 0;
}
void serveAutomaticCapture() {
  if (!authorizeAutomatic()) return;
  String json = "{\"version\":1,\"device_id\":\"" + deviceId + "\",\"crop\":\"" + sensorCrop +
    "\",\"enabled\":" + (automatic.enabled ? "true" : "false") +
    ",\"camera\":\"" + automatic.camera + "\",\"camera_id\":\"" + automatic.cameraId + "\"" +
    ",\"duration\":" + String(automatic.duration) + ",\"cooldown\":" + String(automatic.cooldown) +
    ",\"soil_calibrated\":" + (SOIL_CALIBRATED && DRY_VALUE != WET_VALUE ? "true" : "false") +
    ",\"status\":\"" + autoStatus + "\"";
  const char *names[] = {"temp", "humidity", "soil"};
  for (int i = 0; i < 3; ++i) {
    json += ",\"" + String(names[i]) + "_enabled\":" + (automatic.selected[i] ? "true" : "false");
    json += ",\"" + String(names[i]) + "_min\":" + String(automatic.minimum[i], 2);
    json += ",\"" + String(names[i]) + "_max\":" + String(automatic.maximum[i], 2);
  }
  server.send(200, "application/json", json + "}");
}
bool autoNumber(const String &text, float &value) {
  if (text.length() == 0 || text.length() > 12) return false;
  char *end;
  value = strtof(text.c_str(), &end);
  return *end == '\0' && isfinite(value);
}
void changeAutomaticCapture() {
  if (!authorizeAutomatic()) return;
  if (server.arg("device_id") != deviceId || server.arg("crop") != sensorCrop) {
    server.send(409, "application/json", "{\"error\":\"wrong_device_or_crop\"}"); return;
  }
  AutoCaptureConfig next = automatic;
  if (server.arg("enabled") == "0" && server.args() == 3) {
    if (!disableAutomaticCapture()) {
      configurationReady = false;
      server.send(503, "application/json", "{\"error\":\"save_failed_restart_sensor\"}"); return;
    }
    serveAutomaticCapture(); return;
  }
  bool valid = server.args() == 17 && server.arg("enabled") == "1";
  next.enabled = true;
  strlcpy(next.crop, sensorCrop.c_str(), sizeof(next.crop));
  const String ip = server.arg("camera"), id = server.arg("camera_id"), key = server.arg("camera_key");
  valid &= ip.length() < sizeof(next.camera) && id.length() == 12 && key.length() == 32;
  strlcpy(next.camera, ip.c_str(), sizeof(next.camera));
  strlcpy(next.cameraId, id.c_str(), sizeof(next.cameraId));
  strlcpy(next.cameraKey, key.c_str(), sizeof(next.cameraKey));
  float duration = 0, cooldown = 0;
  valid &= autoNumber(server.arg("duration"), duration) && duration >= 10 && duration <= 3600 && floorf(duration) == duration;
  valid &= autoNumber(server.arg("cooldown"), cooldown) && cooldown >= 60 && cooldown <= 86400 && floorf(cooldown) == cooldown;
  if (valid) { next.duration = (uint32_t)duration; next.cooldown = (uint32_t)cooldown; }
  const char *names[] = {"temp", "humidity", "soil"};
  for (int i = 0; i < 3; ++i) {
    String name(names[i]);
    String selected = server.arg(name + "_enabled");
    valid &= selected == "0" || selected == "1";
    next.selected[i] = selected == "1";
    valid &= autoNumber(server.arg(name + "_min"), next.minimum[i]);
    valid &= autoNumber(server.arg(name + "_max"), next.maximum[i]);
  }
  valid &= !next.selected[2] || (SOIL_CALIBRATED && DRY_VALUE != WET_VALUE);
  if (!valid || !validAutomatic(next)) {
    server.send(400, "application/json", "{\"error\":\"invalid_automation\"}"); return;
  }
  if (!persistAutomatic(next)) {
    automatic.enabled = false;
    configurationReady = false;
    server.send(503, "application/json", "{\"error\":\"save_failed_restart_sensor\"}"); return;
  }
  serveAutomaticCapture();
}

void evaluateAutomaticCapture(float temperature, float humidity, float soil) {
  if (!configurationReady || !automatic.enabled || String(automatic.crop) != sensorCrop) return;
  float values[] = {temperature, humidity, soil};
  if (!automaticTiming.update(millis(), values, automatic.selected, automatic.minimum,
      automatic.maximum, automatic.duration, automatic.cooldown)) return;
  if (WiFi.status() != WL_CONNECTED) { autoStatus = "wifi_unavailable"; return; }
  WiFiClient transport;
  HTTPClient http;
  http.setConnectTimeout(2000);
  http.setTimeout(4000);
  http.setFollowRedirects(HTTPC_DISABLE_FOLLOW_REDIRECTS);
  if (!http.begin(transport, "http://" + String(automatic.camera) + "/auto-capture")) {
    autoStatus = "camera_unavailable"; return;
  }
  http.addHeader("X-AgriSense-Key", automatic.cameraKey);
  http.addHeader("X-Camera-Id", automatic.cameraId);
  http.addHeader("X-Crop", sensorCrop);
  http.addHeader("X-Event-Id", bootId + "-" + String(sampleSequence));
  const char *responseHeaders[] = {"X-Camera-Id"};
  http.collectHeaders(responseHeaders, 1);
  int result = http.POST("");
  autoStatus = result == 200 && http.header("X-Camera-Id") == automatic.cameraId ? "saved" : result == 401 ? "camera_pairing_rejected" :
    result == 409 ? "camera_identity_mismatch" : result == 503 ? "camera_sd_unavailable" :
    result == 429 ? "camera_cooldown" : "camera_unavailable";
  http.end();
  Serial.println("Automatic capture: " + autoStatus);
}
