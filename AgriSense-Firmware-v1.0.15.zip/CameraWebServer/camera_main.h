#pragma once
#include "esp_camera.h"
#include "board_config.h"
#include "demo_network.h"
#include "camera_runtime.h"

volatile bool demoCameraReady = false;
SemaphoreHandle_t demoCameraMutex = nullptr;
DemoNetwork network("camera");
void startCameraServer();
void initializeCameraStorage();
void setupLedFlash();
bool demoCameraHttpReady();

static void initializeCamera() {
  CameraAccess access;
  if (!access.locked() || demoCameraReady) return;
  camera_config_t config = {};
  config.ledc_channel = LEDC_CHANNEL_0;
  config.ledc_timer = LEDC_TIMER_0;
  config.pin_d0 = Y2_GPIO_NUM;
  config.pin_d1 = Y3_GPIO_NUM;
  config.pin_d2 = Y4_GPIO_NUM;
  config.pin_d3 = Y5_GPIO_NUM;
  config.pin_d4 = Y6_GPIO_NUM;
  config.pin_d5 = Y7_GPIO_NUM;
  config.pin_d6 = Y8_GPIO_NUM;
  config.pin_d7 = Y9_GPIO_NUM;
  config.pin_xclk = XCLK_GPIO_NUM;
  config.pin_pclk = PCLK_GPIO_NUM;
  config.pin_vsync = VSYNC_GPIO_NUM;
  config.pin_href = HREF_GPIO_NUM;
  config.pin_sccb_sda = SIOD_GPIO_NUM;
  config.pin_sccb_scl = SIOC_GPIO_NUM;
  config.pin_pwdn = PWDN_GPIO_NUM;
  config.pin_reset = RESET_GPIO_NUM;
  config.xclk_freq_hz = 20000000;
  config.pixel_format = PIXFORMAT_JPEG;
  config.frame_size = FRAMESIZE_QVGA;
  config.jpeg_quality = 12;
  config.fb_count = 1;
  config.grab_mode = CAMERA_GRAB_WHEN_EMPTY;
  config.fb_location = psramFound() ? CAMERA_FB_IN_PSRAM : CAMERA_FB_IN_DRAM;
  const esp_err_t error = esp_camera_init(&config);
  if (error != ESP_OK) {
    Serial.printf("Camera unavailable (0x%x); network stays active.\n", error);
    esp_camera_deinit();
    return;
  }
  sensor_t *sensor = esp_camera_sensor_get();
  if (!sensor) { esp_camera_deinit(); return; }
  if (sensor->id.PID == OV3660_PID) {
    sensor->set_vflip(sensor, 1);
    sensor->set_brightness(sensor, 1);
    sensor->set_saturation(sensor, -2);
  }
#if defined(LED_GPIO_NUM)
  setupLedFlash();
#endif
  initializeCameraStorage();
  demoCameraReady = true;
  Serial.printf("Camera ready, sensor 0x%x, PSRAM %s.\n", sensor->id.PID, psramFound() ? "present" : "absent");
}

void setup() {
  Serial.begin(115200);
  demoCameraMutex = xSemaphoreCreateMutex();
  network.begin();
  startCameraServer();
  initializeCamera();
}

void loop() {
  network.tick();
  static uint32_t cameraAttempt = millis();
  static uint32_t serverAttempt = millis();
  if (!demoCameraHttpReady() && millis() - serverAttempt >= 10000) {
    serverAttempt = millis();
    startCameraServer();
  }
  if (!demoCameraReady && millis() - cameraAttempt >= 10000) {
    cameraAttempt = millis();
    initializeCamera();
  }
  delay(10);
}
