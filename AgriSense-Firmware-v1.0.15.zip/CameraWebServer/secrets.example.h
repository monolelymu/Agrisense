#pragma once
// Copy to secrets.h in each sketch folder. Keep secrets.h private.
#define AGRISENSE_WIFI_SSID "YOUR_HUAWEI_WIFI_NAME"
#define AGRISENSE_WIFI_PASSWORD "YOUR_WIFI_PASSWORD"
#define AGRISENSE_KIT_ID "agrisense-demo-kit"
