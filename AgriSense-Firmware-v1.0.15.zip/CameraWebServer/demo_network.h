#pragma once
#include <WiFi.h>
#include <ESPmDNS.h>
#include <esp_system.h>
#if __has_include("secrets.h")
#include "secrets.h"
#endif
#ifndef AGRISENSE_WIFI_SSID
#define AGRISENSE_WIFI_SSID ""
#endif
#ifndef AGRISENSE_WIFI_PASSWORD
#define AGRISENSE_WIFI_PASSWORD ""
#endif
#ifndef AGRISENSE_KIT_ID
#define AGRISENSE_KIT_ID "agrisense-demo-kit"
#endif

// Keep the copy in the other standalone sketch identical.
static String demoDeviceId() {
  const uint64_t mac = ESP.getEfuseMac();
  char id[13];
  snprintf(id, sizeof(id), "%04x%08lx", (unsigned int)(mac >> 32), (unsigned long)(mac & 0xffffffff));
  return String(id);
}
static String demoIdentity(const char *role, bool ready, const char *capabilities, const String &crop = "") {
  return String("{\"version\":1,\"kit_id\":\"") + AGRISENSE_KIT_ID +
    "\",\"device_id\":\"" + demoDeviceId() + "\",\"role\":\"" + role +
    "\",\"ready\":" + (ready ? "true" : "false") + ",\"capabilities\":" + capabilities +
    (crop.length() ? ",\"sensor_crop\":\"" + crop + "\"" : "") + "}";
}

class DemoNetwork {
 public:
  explicit DemoNetwork(const char *role) : role_(role) {}
  void begin() {
    host_ = String("agrisense-") + role_ + "-" + demoDeviceId().substring(6);
    WiFi.mode(WIFI_STA);
    WiFi.setHostname(host_.c_str());
    WiFi.setAutoReconnect(false); // Only this retry owner controls reconnects.
    WiFi.setSleep(false);
    if (strlen(AGRISENSE_WIFI_SSID)) WiFi.begin(AGRISENSE_WIFI_SSID, AGRISENSE_WIFI_PASSWORD);
    else Serial.println("Wi-Fi credentials are not configured in secrets.h.");
    attemptedAt_ = millis();
  }
  void tick() {
    const uint32_t now = millis();
    const bool online = WiFi.status() == WL_CONNECTED && WiFi.localIP() != IPAddress(0, 0, 0, 0);
    if (online) {
      if (!connected_ || address_ != WiFi.localIP()) {
        if (advertised_) MDNS.end();
        advertised_ = false;
        connected_ = true;
        address_ = WiFi.localIP();
        retry_ = 0;
        mdnsAt_ = now - 5000;
        Serial.println(String(role_) + " connected.");
      }
      if (!advertised_ && now - mdnsAt_ >= 5000) {
        mdnsAt_ = now;
        if (MDNS.begin(host_.c_str())) {
          MDNS.addService("agrisense", "tcp", 80);
          MDNS.addServiceTxt("agrisense", "tcp", "version", "1");
          MDNS.addServiceTxt("agrisense", "tcp", "kit_id", AGRISENSE_KIT_ID);
          MDNS.addServiceTxt("agrisense", "tcp", "role", role_);
          MDNS.addServiceTxt("agrisense", "tcp", "device_id", demoDeviceId().c_str());
          advertised_ = true;
        }
      }
      return;
    }
    if (connected_) {
      connected_ = false;
      if (advertised_) MDNS.end();
      advertised_ = false;
      retry_ = 0;
      attemptedAt_ = now;
    }
    static const uint32_t delays[] = {2000, 5000, 10000, 30000};
    if (strlen(AGRISENSE_WIFI_SSID) && now - attemptedAt_ >= delays[retry_]) {
      attemptedAt_ = now;
      if (retry_ < 3) ++retry_;
      WiFi.reconnect();
    }
  }
 private:
  const char *role_;
  String host_;
  IPAddress address_;
  bool connected_ = false, advertised_ = false;
  uint8_t retry_ = 0;
  uint32_t attemptedAt_ = 0, mdnsAt_ = 0;
};
