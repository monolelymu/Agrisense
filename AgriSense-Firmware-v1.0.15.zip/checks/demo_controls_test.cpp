#include "esp32-hal-ledc.h"
#include "../sensor_node_full/warning_rules.h"
WarningConfig warningConfig;
String sensorCrop = "tomato";
bool dhtSampled = true;
uint32_t dhtSampleMillis = 0;
float latestTemperature = 35, latestHumidity = 70;
int latestSoilRaw = 1500, latestSoilPercent = 0, latestGasRaw = 700;
const bool SOIL_CALIBRATED = false;
const int DRY_VALUE = 3000, WET_VALUE = 1200;
#include "../sensor_node_full/demo_controls.h"
#include <iostream>

static void move(const char *id, const char *action) {
  server.fields = {{"version", "1"}, {"device_id", deviceId}, {"request_id", id}, {"action", action}};
  movePanTilt();
}
static void settle() {
  for (int i = 0; i < 40; ++i) { testMillis += 20; tickDemoControls(); }
}
int main() {
  beginDemoControls();
  assert(servosReady && levels.size() == 3 && duties.size() == 2);
  move("abc-1", "left"); assert(server.status == 200 && panTarget == 80);
  const String firstReceipt = server.response;
  move("abc-1", "left"); assert(server.response == firstReceipt && panTarget == 80);
  move("abc-1", "right"); assert(server.status == 409 && panTarget == 80);
  move("abc-2", "right"); assert(server.status == 409); // No queued movement.
  settle();
  for (int i = 2; i <= 22; ++i) {
    const std::string id = "abc-" + std::to_string(i);
    move(id.c_str(), "left"); assert(server.status == 200); settle();
  }
  assert(panAngle == SERVO_MIN);
  move("abc-1", "left"); assert(server.status == 409 && panTarget == SERVO_MIN);
  move("abc-23", "center"); settle(); assert(panAngle == 90 && tiltAngle == 90);
  move("abc-24", "up"); settle(); assert(tiltAngle == 100);
  move("abc-25", "down"); settle(); assert(tiltAngle == 90);
  move("abc-26", "right"); settle(); assert(panAngle == 100);
  move("abc-27", "sweep"); assert(server.status == 400);
  move("abc-27", "left"); assert(server.status == 200); settle();
  move("abb-99", "left"); assert(server.status == 409);
  move("abc-28", "left"); server.fields["device_id"] = "wrong"; movePanTilt(); assert(server.status == 409);
  server.fields = {{"version", "1"}, {"device_id", deviceId}, {"session_id", "abc"},
    {"camera_ready", "1"}, {"camera_device_id", "112233445566"}};
  receiveAppStatus(); assert(server.status == 200 && levels.size() == 3);
  warningConfig.configured = true;
  for (int i = 0; i < 4; i++) warningConfig.selected[i] = true;
  warningConfig.maximum[0] = 30;
  warningConfig.minimum[2] = 2000;
  warningConfig.maximum[3] = 600;
  assert(validWarning(warningConfig));
  sampleMillis = dhtSampleMillis = testMillis; tickDemoControls();
  assert(levels[DHT_LED] == HIGH && levels[SOIL_LED] == HIGH && levels[MQ_LED] == HIGH);
  latestTemperature = NAN; tickDemoControls(); assert(levels[DHT_LED] == LOW);
  latestHumidity = 101; warningConfig.maximum[1] = 80; tickDemoControls(); assert(levels[DHT_LED] == LOW);
  // Invalid values must be filtered by sampling, represented here as NAN.
  latestHumidity = NAN; tickDemoControls(); assert(levels[DHT_LED] == LOW);
  latestHumidity = 90; tickDemoControls(); assert(levels[DHT_LED] == HIGH);
  WiFi.state = 0; tickDemoControls(); assert(levels[DHT_LED] == HIGH); // Independent of phone/Wi-Fi.
  testMillis += 5001; tickDemoControls();
  assert(levels[DHT_LED] == LOW && levels[SOIL_LED] == LOW && levels[MQ_LED] == LOW);
  panAngle = 76; panTarget = 75; testMillis += 20; tickDemoControls(); assert(panAngle == 75);
  panTarget = 76; testMillis += 20; tickDemoControls(); assert(panAngle == 76);
  warningConfig.minimum[3] = 4095; assert(!validWarning(warningConfig));
  warningConfig.minimum[3] = 0; warningConfig.maximum[3] = 4096; assert(!validWarning(warningConfig));
  attachOk = false; beginDemoControls(); assert(!servosReady);
  move("abd-1", "left"); assert(server.status == 503);
  std::cout << "PASS: bounded movement, duplicate/stale rejection, three warning LEDs, missing/expired samples, offline warnings, gas bounds, PWM failure\n";
}
