# Sensor pan/tilt demo

Use the README one folder above for wiring and flashing. Open sensor_node_full.ino with its neighboring headers intact. Requires the existing ESP32 Arduino 3.x core and existing DHT/RTClib libraries; no servo library is needed.
