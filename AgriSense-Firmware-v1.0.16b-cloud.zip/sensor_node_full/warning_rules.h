#pragma once
#include <math.h>
#include <stdint.h>

struct WarningConfig {
  uint32_t version = 1;
  char crop[12] = "tomato";
  bool configured = false, soilRaw = true;
  bool selected[4] = {false, false, false, false};
  float minimum[4] = {-40, 0, 0, 0};
  float maximum[4] = {80, 100, 4095, 4095};
};
inline bool validWarning(const WarningConfig &c) {
  if (c.version != 1 || c.crop[11] != 0) return false;
  for (int i = 0; i < 4; i++) {
    const float high = i == 0 ? 80 : i == 3 || (i == 2 && c.soilRaw) ? 4095 : 100;
    if (!isfinite(c.minimum[i]) || !isfinite(c.maximum[i]) ||
        c.minimum[i] < (i == 0 ? -40 : 0) || c.maximum[i] > high ||
        c.minimum[i] >= c.maximum[i]) return false;
  }
  return true;
}
inline bool warningOutside(const WarningConfig &c, int i, float value,
                           bool fresh, bool valid) {
  const float upper = i == 0 ? 80 : i == 3 || (i == 2 && c.soilRaw) ? 4095 : 100;
  return c.configured && c.selected[i] && fresh && valid && isfinite(value) &&
    value >= (i == 0 ? -40 : 0) && value <= upper &&
    (value < c.minimum[i] || value > c.maximum[i]);
}
inline int servoNext(int angle, int target, int increment) {
  if (angle < target) return angle + increment > target ? target : angle + increment;
  return angle - increment < target ? target : angle - increment;
}
