#pragma once
#include "warning_rules.h"
WarningConfig warningConfig;

bool persistWarnings(const WarningConfig &next) {
  if (preferences.putBytes("led_warnings", &next, sizeof(next)) != sizeof(next)) return false;
  WarningConfig check;
  if (preferences.getBytes("led_warnings", &check, sizeof(check)) != sizeof(check) ||
      memcmp(&check, &next, sizeof(next)) != 0) return false;
  warningConfig = next;
  return true;
}
bool clearWarnings() {
  WarningConfig next;
  strlcpy(next.crop, sensorCrop.c_str(), sizeof(next.crop));
  warningConfig.configured = false;
  return persistWarnings(next);
}
void loadWarnings() {
  WarningConfig loaded;
  if (preferences.getBytesLength("led_warnings") == sizeof(loaded) &&
      preferences.getBytes("led_warnings", &loaded, sizeof(loaded)) == sizeof(loaded) &&
      validWarning(loaded) && String(loaded.crop) == sensorCrop &&
      (!loaded.selected[2] || loaded.soilRaw || SOIL_CALIBRATED)) warningConfig = loaded;
}
String warningJson() {
  String json = "{\"version\":1,\"device_id\":\"" + deviceId + "\",\"crop\":\"" + sensorCrop +
    "\",\"configured\":" + (warningConfig.configured ? "true" : "false") +
    ",\"soil_raw\":" + (warningConfig.soilRaw ? "true" : "false");
  const char *names[] = {"temp", "humidity", "soil", "gas"};
  for (int i = 0; i < 4; i++) {
    const String name(names[i]);
    json += ",\"" + name + "_enabled\":" + (warningConfig.selected[i] ? "true" : "false");
    json += ",\"" + name + "_min\":" + String(warningConfig.minimum[i], 4);
    json += ",\"" + name + "_max\":" + String(warningConfig.maximum[i], 4);
  }
  return json + "}";
}
void serveWarnings() {
  if (!authorizeAutomatic()) return;
  server.send(200, "application/json", warningJson());
}
void changeWarnings() {
  if (!authorizeAutomatic()) return;
  if (server.arg("device_id") != deviceId || server.arg("crop") != sensorCrop) {
    server.send(409, "application/json", "{\"error\":\"wrong_device_or_crop\"}"); return;
  }
  WarningConfig next;
  strlcpy(next.crop, sensorCrop.c_str(), sizeof(next.crop));
  bool valid = server.args() == 16 && server.arg("version") == "1" &&
    (server.arg("soil_raw") == "0" || server.arg("soil_raw") == "1");
  next.configured = true;
  next.soilRaw = server.arg("soil_raw") == "1";
  const char *names[] = {"temp", "humidity", "soil", "gas"};
  for (int i = 0; i < 4; i++) {
    const String name(names[i]);
    const String enabled = server.arg(name + "_enabled");
    valid &= enabled == "0" || enabled == "1";
    next.selected[i] = enabled == "1";
    valid &= autoNumber(server.arg(name + "_min"), next.minimum[i]);
    valid &= autoNumber(server.arg(name + "_max"), next.maximum[i]);
  }
  valid &= !next.selected[2] || next.soilRaw || (SOIL_CALIBRATED && DRY_VALUE != WET_VALUE);
  if (!valid || !validWarning(next)) {
    server.send(400, "application/json", "{\"error\":\"invalid_warning_limits\"}"); return;
  }
  // Identical retries acknowledge without another flash write.
  bool same = warningConfig.configured && warningConfig.soilRaw == next.soilRaw &&
    String(warningConfig.crop) == String(next.crop);
  for (int i = 0; i < 4; i++) same &= warningConfig.selected[i] == next.selected[i] &&
    warningConfig.minimum[i] == next.minimum[i] && warningConfig.maximum[i] == next.maximum[i];
  if (same) {
    server.send(200, "application/json", warningJson()); return;
  }
  if (!persistWarnings(next)) {
    warningConfig.configured = false;
    configurationReady = false;
    server.send(503, "application/json", "{\"error\":\"save_failed_restart_sensor\"}"); return;
  }
  server.send(200, "application/json", warningJson());
}
