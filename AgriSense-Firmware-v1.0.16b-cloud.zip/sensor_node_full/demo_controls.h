#pragma once
#include <esp32-hal-ledc.h>

// ESP32 Arduino 3.x core only; no additional servo library.
constexpr uint8_t PAN_PIN = 25, TILT_PIN = 26;
constexpr uint8_t DHT_LED = 14, SOIL_LED = 27, MQ_LED = 33;
constexpr int SERVO_CENTER = 90, SERVO_MIN = 75, SERVO_MAX = 105;
constexpr int SERVO_STEP = 10;
constexpr int SERVO_INCREMENT = 2;
constexpr uint32_t SERVO_TICK_MS = 20;
constexpr uint32_t SERVO_SETTLE_MS = 250, SERVO_STARTUP_MS = 750;
// Reverse one sign if the physical mount moves in the opposite direction.
constexpr int PAN_SIGN = 1, TILT_SIGN = 1;
bool servosReady = false;
bool servoRadioBusy = false;
uint8_t servoStartupStage = 0;
uint32_t servoChangedAt = 0;
int panAngle = SERVO_CENTER, tiltAngle = SERVO_CENTER;
int panTarget = SERVO_CENTER, tiltTarget = SERVO_CENTER;
uint32_t servoTickAt = 0, phoneSeenAt = 0;
bool phoneSeen = false, relayedCameraReady = false, dhtValid = false;

struct MovementReceipt {
  String request, action, json;
};
MovementReceipt movementReceipts[16];
uint8_t receiptIndex = 0;
uint64_t newestSession = 0;
uint32_t newestSequence = 0;

static void writeServo(uint8_t pin, int angle) {
  // 50 Hz, 16 bits, conservative 1000..2000 us pulse mapping.
  const uint32_t pulseUs = 1000 + (uint32_t)angle * 1000 / 180;
  ledcWrite(pin, pulseUs * 65535UL / 20000UL);
}

static void beginDemoControls() {
  const uint8_t leds[] = {DHT_LED, SOIL_LED, MQ_LED};
  for (uint8_t pin : leds) { pinMode(pin, OUTPUT); digitalWrite(pin, LOW); }
  const bool panOk = ledcAttach(PAN_PIN, 50, 16);
  servosReady = false;
  servoStartupStage = 0;
  if (panOk) {
    writeServo(PAN_PIN, panAngle);
    servoChangedAt = millis();
    servoStartupStage = 1;
  }
}

static bool servoPowerBusy() {
  return servoStartupStage != 0 || (servosReady &&
    (panAngle != panTarget || tiltAngle != tiltTarget || millis() - servoChangedAt < SERVO_SETTLE_MS));
}

static void tickDemoControls() {
  const uint32_t now = millis();
  if (servoStartupStage && now - servoChangedAt >= SERVO_STARTUP_MS) {
    if (servoStartupStage == 1) {
      if (ledcAttach(TILT_PIN, 50, 16)) {
        writeServo(TILT_PIN, tiltAngle);
        servoChangedAt = now;
        servoStartupStage = 2;
      } else {
        ledcDetach(PAN_PIN);
        servoStartupStage = 0;
      }
    } else {
      servoStartupStage = 0;
      servosReady = true;
    }
  }
  if (servosReady && now - servoTickAt >= SERVO_TICK_MS) {
    servoTickAt = now;
    if (panAngle != panTarget) {
      panAngle = servoNext(panAngle, panTarget, SERVO_INCREMENT);
      writeServo(PAN_PIN, panAngle);
      servoChangedAt = now;
    } else if (tiltAngle != tiltTarget && now - servoChangedAt >= SERVO_SETTLE_MS) {
      tiltAngle = servoNext(tiltAngle, tiltTarget, SERVO_INCREMENT);
      writeServo(TILT_PIN, tiltAngle);
      // Allow successive tilt steps; settle only on completion.
      if (tiltAngle == tiltTarget) servoChangedAt = now;
    }
  }
  const bool fresh = sampleSequence > 0 && now - sampleMillis <= 5000;
  const bool dhtFresh = dhtSampled && now - dhtSampleMillis <= 5000;
  const bool active = configurationReady && String(warningConfig.crop) == sensorCrop;
  digitalWrite(DHT_LED, active && (warningOutside(warningConfig, 0, latestTemperature, dhtFresh, true) ||
    warningOutside(warningConfig, 1, latestHumidity, dhtFresh, true)) ? HIGH : LOW);
  const bool calibrated = SOIL_CALIBRATED && DRY_VALUE != WET_VALUE;
  digitalWrite(SOIL_LED, active && warningOutside(warningConfig, 2,
    warningConfig.soilRaw ? latestSoilRaw : latestSoilPercent, fresh,
    warningConfig.soilRaw || calibrated) ? HIGH : LOW);
  digitalWrite(MQ_LED, active && warningOutside(warningConfig, 3, latestGasRaw, fresh, true) ? HIGH : LOW);
}

static bool boundedHex(const String &text, size_t maxLength) {
  if (text.length() == 0 || text.length() > maxLength) return false;
  for (size_t i = 0; i < text.length(); ++i) {
    const char c = text[i];
    if (!((c >= '0' && c <= '9') || (c >= 'a' && c <= 'f'))) return false;
  }
  return true;
}

static void controlError(int status, const char *error) {
  server.send(status, "application/json", String("{\"error\":\"") + error + "\"}");
}

static bool controlDeviceMatches() {
  server.sendHeader("Cache-Control", "no-store");
  if (!configurationReady) { controlError(503, "configuration_unavailable"); return false; }
  if (server.arg("version") != "1") { controlError(400, "invalid_version"); return false; }
  if (server.arg("device_id") != deviceId) { controlError(409, "wrong_device"); return false; }
  return true;
}

static void movePanTilt() {
  if (!controlDeviceMatches()) return;
  if (!servosReady) { controlError(503, "movement_unavailable"); return; }
  if (server.args() != 4) { controlError(400, "invalid_arguments"); return; }
  const String request = server.arg("request_id"), action = server.arg("action");
  const int separator = request.indexOf('-');
  const String session = request.substring(0, separator < 0 ? 0 : separator);
  const String sequence = separator < 0 ? String("") : request.substring(separator + 1);
  if (!boundedHex(session, 16) || sequence.length() == 0 || sequence.length() > 9 ||
      sequence[0] == '0') { controlError(400, "invalid_request_id"); return; }
  for (size_t i = 0; i < sequence.length(); ++i) {
    if (sequence[i] < '0' || sequence[i] > '9') { controlError(400, "invalid_request_id"); return; }
  }
  if (action != "up" && action != "down" && action != "left" && action != "right" && action != "center") {
    controlError(400, "invalid_action"); return;
  }
  for (const MovementReceipt &receipt : movementReceipts) {
    if (receipt.request == request) {
      if (receipt.action != action) { controlError(409, "request_conflict"); return; }
      server.send(200, "application/json", receipt.json); return;
    }
  }
  const uint64_t sessionNumber = strtoull(session.c_str(), nullptr, 16);
  const uint32_t sequenceNumber = strtoul(sequence.c_str(), nullptr, 10);
  // Old requests outside the receipt cache fail closed instead of moving again.
  if (sessionNumber < newestSession || (sessionNumber == newestSession && sequenceNumber <= newestSequence)) {
    controlError(409, "stale_request"); return;
  }
  // Do not queue a sweep while the previous small move is still finishing.
  if (servoPowerBusy() || servoRadioBusy) { controlError(409, "movement_busy"); return; }
  if (action == "left") panTarget -= PAN_SIGN * SERVO_STEP;
  if (action == "right") panTarget += PAN_SIGN * SERVO_STEP;
  if (action == "up") tiltTarget += TILT_SIGN * SERVO_STEP;
  if (action == "down") tiltTarget -= TILT_SIGN * SERVO_STEP;
  if (action == "center") { panTarget = SERVO_CENTER; tiltTarget = SERVO_CENTER; }
  panTarget = constrain(panTarget, SERVO_MIN, SERVO_MAX);
  tiltTarget = constrain(tiltTarget, SERVO_MIN, SERVO_MAX);
  newestSession = sessionNumber; newestSequence = sequenceNumber;
  const String json = String("{\"version\":1,\"device_id\":\"") + deviceId +
    "\",\"request_id\":\"" + request + "\",\"ready\":true,\"pan\":" + panTarget + ",\"tilt\":" + tiltTarget + "}";
  movementReceipts[receiptIndex] = {request, action, json};
  receiptIndex = (receiptIndex + 1) % 16;
  server.send(200, "application/json", json);
}

static void receiveAppStatus() {
  if (!controlDeviceMatches()) return;
  const String camera = server.arg("camera_device_id"), ready = server.arg("camera_ready");
  if (server.args() != 5 || !boundedHex(server.arg("session_id"), 16) ||
      (ready != "0" && ready != "1") ||
      (camera.length() && (!boundedHex(camera, 12) || camera.length() != 12)) ||
      (ready == "1" && camera.length() != 12)) {
    controlError(400, "invalid_status"); return;
  }
  phoneSeenAt = millis(); phoneSeen = true; relayedCameraReady = ready == "1";
  tickDemoControls();
  server.send(200, "application/json", String("{\"version\":1,\"device_id\":\"") + deviceId + "\"}");
}
