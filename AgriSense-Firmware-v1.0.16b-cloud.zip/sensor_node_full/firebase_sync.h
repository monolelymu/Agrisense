#pragma once
#include <cmath>
#if defined(ARDUINO)
#include <Arduino.h>
#endif

#ifndef AGRISENSE_KIT_ID
#define AGRISENSE_KIT_ID "agrisense-demo-kit"
#endif
#ifndef AGRISENSE_FIREBASE_URL
#define AGRISENSE_FIREBASE_URL "https://agrisense-3eba5-default-rtdb.asia-southeast1.firebasedatabase.app"
#endif
#ifndef AGRISENSE_FIREBASE_API_KEY
#define AGRISENSE_FIREBASE_API_KEY "AIzaSyCdXw00WR8x2TYnse4NJAs2O2_pQ0QYA0c"
#endif

// Helper function to extract a string field from a JSON object without requiring dynamic allocations or full parsers.
static inline String jsonStringField(const String &json, const String &key) {
  const String needle = String("\"") + key + "\":";
  int idx = json.indexOf(needle);
  if (idx < 0) return "";
  int valStart = idx + (int)needle.length();
  while (valStart < (int)json.length() && (json[valStart] == ' ' || json[valStart] == '\t')) {
    ++valStart;
  }
  if (valStart >= (int)json.length() || json[valStart] != '"') return "";
  ++valStart;
  int valEnd = json.indexOf('"', valStart);
  if (valEnd < valStart) return "";
  return json.substring(valStart, valEnd);
}

// Builds the open-brace readings JSON prefix used by both local /readings and cloud sync.
static inline String buildOpenReadingsJson(
    const String &devId,
    const String &crop,
    const String &bootId,
    unsigned long seq,
    float temperature,
    float humidity,
    int soilRaw,
    bool soilCalibrated,
    int soilPercent,
    int gasRaw) {
  return String("{\"version\":1,\"device_id\":\"") + devId + "\",\"crop\":\"" + crop +
    "\",\"sample_id\":\"" + bootId + "-" + String(seq) + "\"" +
    ",\"temp_c\":" + (!std::isfinite(temperature) || temperature < -40 || temperature > 80 ? String("null") : String(temperature, 1)) +
    ",\"humidity_pct\":" + (!std::isfinite(humidity) || humidity < 0 || humidity > 100 ? String("null") : String(humidity, 1)) +
    ",\"soil_raw\":" + String(soilRaw) +
    ",\"soil_pct\":" + (soilCalibrated ? String(soilPercent) : String("null")) +
    ",\"soil_calibrated\":" + (soilCalibrated ? String("true") : String("false")) +
    ",\"gas_raw\":" + String(gasRaw);
}

// Appends dht_age_ms and age_ms and closes the readings JSON object.
static inline String closeReadingsJson(
    const String &openReadingsJson,
    unsigned long dhtAgeMs,
    unsigned long sampleAgeMs) {
  return openReadingsJson +
    ",\"dht_age_ms\":" + String(dhtAgeMs) +
    ",\"age_ms\":" + String(sampleAgeMs) + "}";
}

// Builds the complete /kits/demo/sensor.json payload with uploaded_at_ms at the sensor root.
static inline String buildSensorCloudPayload(
    const String &identityJson,
    const String &openReadingsJson,
    unsigned long dhtAgeMs,
    unsigned long sampleAgeMs) {
  return String("{\"identity\":") + identityJson +
    ",\"readings\":" + closeReadingsJson(openReadingsJson, dhtAgeMs, sampleAgeMs) +
    ",\"uploaded_at_ms\":{\".sv\":\"timestamp\"}}";
}

// Manages boot-time command seeding, target device ID matching, and replay deduplication.
class CloudDeduplicator {
 public:
  explicit CloudDeduplicator(const String &myDeviceId = "") : myDeviceId_(myDeviceId) {}

  void setDeviceId(const String &id) { myDeviceId_ = id; }
  const String &getDeviceId() const { return myDeviceId_; }

  bool isBootSeeded() const { return bootSeeded_; }
  const String &getLastRequestId() const { return lastRequestId_; }

  void seed(const String &initialRequestId) {
    lastRequestId_ = initialRequestId;
    bootSeeded_ = true;
  }

  bool shouldExecute(const String &targetDeviceId, const String &requestId) const {
    if (!bootSeeded_) return false;
    if (requestId.length() == 0) return false;
    if (myDeviceId_.length() > 0 && targetDeviceId.length() > 0 && targetDeviceId != myDeviceId_) return false;
    if (requestId == lastRequestId_) return false;
    return true;
  }

  void markExecuted(const String &requestId) {
    lastRequestId_ = requestId;
  }

  void reset() {
    bootSeeded_ = false;
    lastRequestId_ = "";
  }

 private:
  String myDeviceId_;
  String lastRequestId_;
  bool bootSeeded_ = false;
};

#if defined(ARDUINO)
#include <WiFiClientSecure.h>
#include <HTTPClient.h>

static String cloudToken = "";
static uint32_t cloudTokenIssuedAt = 0;
static uint32_t lastCloudTelemetryPush = 0;
static uint32_t lastCloudCommandPoll = 0;
static uint8_t cloudTaskTurn = 0;

static CloudDeduplicator commandDeduplicator;
static WiFiClientSecure cloudTlsClient;
static HTTPClient cloudHttpClient;
static bool cloudTlsInited = false;

static void initCloudTls() {
  if (!cloudTlsInited) {
    cloudTlsClient.setInsecure();
    cloudTlsClient.setTimeout(2);
    cloudHttpClient.setReuse(true);
    cloudHttpClient.setConnectTimeout(1500);
    cloudHttpClient.setTimeout(1500);
    cloudTlsInited = true;
  }
}

static bool ensureCloudToken() {
  const uint32_t now = millis();
  if (cloudToken.length() > 0 && now - cloudTokenIssuedAt < 3000000UL) {
    return true;
  }
  if (!strlen(AGRISENSE_FIREBASE_API_KEY)) return false;

  initCloudTls();
  const String url = "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=" + String(AGRISENSE_FIREBASE_API_KEY);
  if (!cloudHttpClient.begin(cloudTlsClient, url)) return false;
  cloudHttpClient.addHeader("Content-Type", "application/json");

  const int code = cloudHttpClient.POST("{\"returnSecureToken\":true}");
  if (code == 200) {
    const String body = cloudHttpClient.getString();
    const String token = jsonStringField(body, "idToken");
    if (token.length() > 0) {
      cloudToken = token;
      cloudTokenIssuedAt = now;
      cloudHttpClient.end();
      return true;
    }
  } else {
    Serial.printf("Firebase sensor auth POST failed (%d).\n", code);
  }
  cloudHttpClient.end();
  return false;
}

static void applyCloudCommand(const String &cmdId, const String &action) {
  if (action == "left") panTarget -= PAN_SIGN * SERVO_STEP;
  else if (action == "right") panTarget += PAN_SIGN * SERVO_STEP;
  else if (action == "up") tiltTarget += TILT_SIGN * SERVO_STEP;
  else if (action == "down") tiltTarget -= TILT_SIGN * SERVO_STEP;
  else if (action == "center") { panTarget = SERVO_CENTER; tiltTarget = SERVO_CENTER; }
  else return;

  panTarget = constrain(panTarget, SERVO_MIN, SERVO_MAX);
  tiltTarget = constrain(tiltTarget, SERVO_MIN, SERVO_MAX);

  if (!ensureCloudToken()) return;
  initCloudTls();
  const String url = String(AGRISENSE_FIREBASE_URL) + "/kits/demo/control/receipt.json?auth=" + cloudToken;
  if (cloudHttpClient.begin(cloudTlsClient, url)) {
    cloudHttpClient.addHeader("Content-Type", "application/json");
    const String receipt = "{\"version\":1,\"device_id\":\"" + demoDeviceId() +
      "\",\"request_id\":\"" + cmdId + "\",\"ready\":true,\"pan\":" + String(panTarget) +
      ",\"tilt\":" + String(tiltTarget) + "}";
    const int code = cloudHttpClient.PUT(receipt);
    if (code != 200) {
      if (code == 401 || code == 403) cloudToken = "";
      Serial.printf("Firebase receipt PUT failed (%d).\n", code);
    }
    cloudHttpClient.end();
  }
}

static void tickFirebaseSync() {
  if (!strlen(AGRISENSE_FIREBASE_URL) || !strlen(AGRISENSE_FIREBASE_API_KEY)) return;
  if (!network.online() || network.connecting() || servoPowerBusy()) return;

  const uint32_t now = millis();
  const bool telemetryDue = (latestJson.length() > 0 && now - lastCloudTelemetryPush >= 3000);
  const bool commandDue = (servosReady && !servoPowerBusy() && now - lastCloudCommandPoll >= 1200);

  if (!telemetryDue && !commandDue) return;

  // Run at most ONE HTTP request per tick pass to prevent blocking loop()
  if (telemetryDue && (cloudTaskTurn == 0 || !commandDue)) {
    cloudTaskTurn = 1;
    lastCloudTelemetryPush = now;
    if (ensureCloudToken()) {
      initCloudTls();
      const String url = String(AGRISENSE_FIREBASE_URL) + "/kits/demo/sensor.json?auth=" + cloudToken;
      if (cloudHttpClient.begin(cloudTlsClient, url)) {
        cloudHttpClient.addHeader("Content-Type", "application/json");
        const String identity = demoIdentity("sensor", configurationReady && latestJson.length() > 0,
          servosReady ? "[\"readings\",\"sd_optional\",\"pan_tilt_v1\",\"app_status_v1\",\"warning_leds_v1\"]" :
            "[\"readings\",\"sd_optional\",\"app_status_v1\",\"warning_leds_v1\"]", sensorCrop);
        const unsigned long dhtAge = dhtSampled ? millis() - dhtSampleMillis : 60000UL;
        const unsigned long sampleAge = millis() - sampleMillis;
        const String payload = buildSensorCloudPayload(identity, latestJson, dhtAge, sampleAge);
        const int code = cloudHttpClient.PUT(payload);
        if (code != 200) {
          if (code == 401 || code == 403) cloudToken = "";
          Serial.printf("Firebase sensor PUT failed (%d).\n", code);
        }
        cloudHttpClient.end();
      }
    }
    return;
  }

  if (commandDue) {
    cloudTaskTurn = 0;
    lastCloudCommandPoll = now;
    if (ensureCloudToken()) {
      initCloudTls();
      commandDeduplicator.setDeviceId(demoDeviceId());
      const String url = String(AGRISENSE_FIREBASE_URL) + "/kits/demo/control/command.json?auth=" + cloudToken;
      if (cloudHttpClient.begin(cloudTlsClient, url)) {
        const int code = cloudHttpClient.GET();
        if (code == 200) {
          const String body = cloudHttpClient.getString();
          const String reqId = jsonStringField(body, "request_id");
          const String targetDevice = jsonStringField(body, "device_id");
          const String action = jsonStringField(body, "action");
          if (!commandDeduplicator.isBootSeeded()) {
            commandDeduplicator.seed(reqId);
          } else if (commandDeduplicator.shouldExecute(targetDevice, reqId)) {
            applyCloudCommand(reqId, action);
            commandDeduplicator.markExecuted(reqId);
          }
        } else {
          if (code == 401 || code == 403) cloudToken = "";
          Serial.printf("Firebase command GET failed (%d).\n", code);
        }
        cloudHttpClient.end();
      }
    }
  }
}

#else

static inline void tickFirebaseSync() {}

#endif
