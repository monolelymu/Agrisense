#pragma once
#include <stdint.h>
#include <math.h>

// Portable timing logic, also exercised by the offline host test.
struct AutoCaptureTiming {
  uint32_t since[3] = {}, lastSample = 0, lastAttempt = 0;
  bool active[3] = {}, sampled = false;
  void reset(uint32_t now) {
    for (int i = 0; i < 3; ++i) active[i] = false;
    sampled = false;
    lastAttempt = now;
  }
  bool update(uint32_t now, const float values[3], const bool selected[3],
      const float minimum[3], const float maximum[3], uint32_t duration, uint32_t cooldown,
      bool allowCapture = true) {
    if (sampled && now - lastSample > 30000)
      for (int i = 0; i < 3; ++i) active[i] = false;
    lastSample = now;
    sampled = true;
    bool trigger = false;
    for (int i = 0; i < 3; ++i) {
      bool bad = selected[i] && isfinite(values[i]) &&
        values[i] >= (i == 0 ? -40 : 0) && values[i] <= (i == 0 ? 80 : 100) &&
        (values[i] < minimum[i] || values[i] > maximum[i]);
      if (!bad) { active[i] = false; continue; }
      if (!active[i]) { active[i] = true; since[i] = now; }
      trigger |= now - since[i] >= duration * 1000UL;
    }
    if (!allowCapture || !trigger || now - lastAttempt < cooldown * 1000UL) return false;
    lastAttempt = now; // Every attempt, including network failure, is throttled.
    return true;
  }
};
