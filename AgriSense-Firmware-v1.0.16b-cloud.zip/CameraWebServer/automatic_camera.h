#pragma once
#include <Preferences.h>
#include "camera_runtime.h"

static String cameraIdentity, cameraPairing, lastAutomaticEvent;
static bool cameraPairingReady = false, automaticAttempted = false;
static uint32_t lastAutomaticAttempt = 0;

static bool cameraHex(const String &s, size_t length) {
  if (s.length() != length) return false;
  for (size_t i = 0; i < length; ++i)
    if (!((s[i] >= '0' && s[i] <= '9') || (s[i] >= 'a' && s[i] <= 'f'))) return false;
  return true;
}
static void beginCameraPairing() {
  uint64_t mac = ESP.getEfuseMac();
  char id[13];
  snprintf(id, sizeof(id), "%04x%08lx", (unsigned int)(mac >> 32), (unsigned long)(mac & 0xffffffff));
  cameraIdentity = id;
  Preferences prefs;
  if (!prefs.begin("camera_pair", false)) return;
  cameraPairing = prefs.getString("key", "");
  if (!cameraHex(cameraPairing, 32)) {
    uint8_t bytes[16];
    esp_fill_random(bytes, sizeof(bytes)); // Wi-Fi radio was enabled before server startup.
    char encoded[33];
    for (int i = 0; i < 16; ++i) snprintf(encoded + i * 2, 3, "%02x", bytes[i]);
    cameraPairing = encoded;
    if (prefs.putString("key", cameraPairing) != 32) { prefs.end(); return; }
  }
  cameraPairingReady = prefs.getString("key", "") == cameraPairing;
  prefs.end();
  if (cameraPairingReady) {
    Serial.println("Camera device ID: " + cameraIdentity);
    // Existing private key remains in NVS; discovery never exposes it.
  }
}
static esp_err_t cameraJson(httpd_req_t *req, const char *status, const char *json) {
  httpd_resp_set_status(req, status);
  httpd_resp_set_type(req, "application/json");
  httpd_resp_set_hdr(req, "Cache-Control", "no-store");
  httpd_resp_set_hdr(req, "X-Camera-Id", cameraIdentity.c_str());
  return httpd_resp_sendstr(req, json);
}
static bool authorizedCamera(httpd_req_t *req) {
  char code[33];
  if (!cameraPairingReady || httpd_req_get_hdr_value_len(req, "X-AgriSense-Key") != 32 ||
      httpd_req_get_hdr_value_str(req, "X-AgriSense-Key", code, sizeof(code)) != ESP_OK) return false;
  uint8_t diff = 0;
  for (int i = 0; i < 32; ++i) diff |= code[i] ^ cameraPairing[i];
  return diff == 0;
}
static esp_err_t automaticCameraInfo(httpd_req_t *req) {
  if (!authorizedCamera(req)) return cameraJson(req, "401 Unauthorized", "{\"error\":\"pairing_required\"}");
  String json = "{\"version\":1,\"device_id\":\"" + cameraIdentity +
    "\",\"sd_ready\":" + (captureStorageReady ? "true" : "false") + "}";
  return cameraJson(req, "200 OK", json.c_str());
}
static esp_err_t automaticCameraCapture(httpd_req_t *req) {
  if (!authorizedCamera(req)) return cameraJson(req, "401 Unauthorized", "{\"error\":\"pairing_required\"}");
  CameraAccess access;
  if (!access.ready()) return cameraJson(req, "503 Service Unavailable", "{\"error\":\"camera_unavailable\"}");
  char id[13], crop[12], event[65];
  if (httpd_req_get_hdr_value_str(req, "X-Camera-Id", id, sizeof(id)) != ESP_OK || cameraIdentity != id)
    return cameraJson(req, "409 Conflict", "{\"error\":\"wrong_device\"}");
  if (req->content_len != 0 ||
      httpd_req_get_hdr_value_str(req, "X-Crop", crop, sizeof(crop)) != ESP_OK ||
      (strcmp(crop, "tomato") && strcmp(crop, "chili") && strcmp(crop, "eggplant")) ||
      httpd_req_get_hdr_value_str(req, "X-Event-Id", event, sizeof(event)) != ESP_OK || !event[0])
    return cameraJson(req, "400 Bad Request", "{\"error\":\"invalid_event\"}");
  for (size_t i = 0; i < strlen(event); ++i)
    if (!((event[i] >= 'a' && event[i] <= 'f') || (event[i] >= '0' && event[i] <= '9') || event[i] == '-'))
      return cameraJson(req, "400 Bad Request", "{\"error\":\"invalid_event\"}");
  if (lastAutomaticEvent == event) return cameraJson(req, "200 OK", "{\"saved\":true}");
  if (!captureStorageReady) return cameraJson(req, "503 Service Unavailable", "{\"error\":\"sd_unavailable\"}");
  uint32_t now = millis();
  if (automaticAttempted && now - lastAutomaticAttempt < 60000)
    return cameraJson(req, "429 Too Many Requests", "{\"error\":\"cooldown\"}");
  lastAutomaticAttempt = now;
  automaticAttempted = true;
  camera_fb_t *fb = esp_camera_fb_get();
  if (!fb) return cameraJson(req, "503 Service Unavailable", "{\"error\":\"capture_failed\"}");
  bool saved = fb->format == PIXFORMAT_JPEG && saveCaptureCopy(fb->buf, fb->len);
  esp_camera_fb_return(fb);
  if (!saved) return cameraJson(req, "503 Service Unavailable", "{\"error\":\"sd_unavailable\"}");
  lastAutomaticEvent = event;
  Serial.printf("Automatic photo saved for %s, event %s\n", crop, event);
  return cameraJson(req, "200 OK", "{\"saved\":true}");
}

static void registerAutomaticCamera(httpd_handle_t handle) {
  httpd_uri_t info = {};
  info.uri = "/automation-info";
  info.method = HTTP_GET;
  info.handler = automaticCameraInfo;
  httpd_register_uri_handler(handle, &info);
  httpd_uri_t capture = {};
  capture.uri = "/auto-capture";
  capture.method = HTTP_POST;
  capture.handler = automaticCameraCapture;
  httpd_register_uri_handler(handle, &capture);
}
