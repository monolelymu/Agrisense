#pragma once
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"
extern volatile bool demoCameraReady;
extern SemaphoreHandle_t demoCameraMutex;
class CameraAccess {
 public:
  explicit CameraAccess(uint32_t waitMs = 1000) {
    held_ = demoCameraMutex && xSemaphoreTake(demoCameraMutex, pdMS_TO_TICKS(waitMs)) == pdTRUE;
  }
  ~CameraAccess() { release(); }
  void release() { if (held_) { xSemaphoreGive(demoCameraMutex); held_ = false; } }
  bool ready() const { return held_ && demoCameraReady; }
  bool locked() const { return held_; }
 private:
  bool held_ = false;
};
