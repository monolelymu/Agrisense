#pragma once
#if defined(ARDUINO)
#include <Arduino.h>
#endif

#ifndef AGRISENSE_KIT_ID
#define AGRISENSE_KIT_ID "agrisense-demo-kit"
#endif
#ifndef AGRISENSE_FIREBASE_URL
#define AGRISENSE_FIREBASE_URL "https://agrisense-3eba5-default-rtdb.asia-southeast1.firebasedatabase.app"
#endif
#ifndef AGRISENSE_FIREBASE_API_KEY
#define AGRISENSE_FIREBASE_API_KEY "AIzaSyCdXw00WR8x2TYnse4NJAs2O2_pQ0QYA0c"
#endif

// Helper function to extract a string field from a JSON object without requiring dynamic allocations or full parsers.
static inline String jsonStringField(const String &json, const String &key) {
  const String needle = String("\"") + key + "\":";
  int idx = json.indexOf(needle);
  if (idx < 0) return "";
  int valStart = idx + (int)needle.length();
  while (valStart < (int)json.length() && (json[valStart] == ' ' || json[valStart] == '\t')) {
    ++valStart;
  }
  if (valStart >= (int)json.length() || json[valStart] != '"') return "";
  ++valStart;
  int valEnd = json.indexOf('"', valStart);
  if (valEnd < valStart) return "";
  return json.substring(valStart, valEnd);
}

// Manages boot-time snapshot request seeding, target device ID matching, and replay deduplication.
class CloudDeduplicator {
 public:
  explicit CloudDeduplicator(const String &myDeviceId = "") : myDeviceId_(myDeviceId) {}

  void setDeviceId(const String &id) { myDeviceId_ = id; }
  const String &getDeviceId() const { return myDeviceId_; }

  bool isBootSeeded() const { return bootSeeded_; }
  const String &getLastRequestId() const { return lastRequestId_; }

  void seed(const String &initialRequestId) {
    lastRequestId_ = initialRequestId;
    bootSeeded_ = true;
  }

  bool shouldExecute(const String &targetDeviceId, const String &requestId) const {
    if (!bootSeeded_) return false;
    if (requestId.length() == 0) return false;
    if (myDeviceId_.length() > 0 && targetDeviceId.length() > 0 && targetDeviceId != myDeviceId_) return false;
    if (requestId == lastRequestId_) return false;
    return true;
  }

  void markExecuted(const String &requestId) {
    lastRequestId_ = requestId;
  }

  void reset() {
    bootSeeded_ = false;
    lastRequestId_ = "";
  }

 private:
  String myDeviceId_;
  String lastRequestId_;
  bool bootSeeded_ = false;
};

#if defined(ARDUINO)
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include "mbedtls/base64.h"
#include "esp_camera.h"
#include "camera_runtime.h"

static String cameraCloudToken = "";
static uint32_t cameraCloudTokenIssuedAt = 0;
static uint32_t lastCameraIdentityPush = 0;
static uint32_t lastCameraRequestPoll = 0;
static uint8_t cameraCloudTaskTurn = 0;

static CloudDeduplicator cameraRequestDeduplicator;
static WiFiClientSecure cameraCloudTlsClient;
static HTTPClient cameraCloudHttpClient;
static bool cameraCloudTlsInited = false;

static void initCameraCloudTls() {
  if (!cameraCloudTlsInited) {
    cameraCloudTlsClient.setInsecure();
    cameraCloudTlsClient.setTimeout(2);
    cameraCloudHttpClient.setReuse(true);
    cameraCloudHttpClient.setConnectTimeout(1500);
    cameraCloudHttpClient.setTimeout(1500);
    cameraCloudTlsInited = true;
  }
}

static bool ensureCameraCloudToken() {
  const uint32_t now = millis();
  if (cameraCloudToken.length() > 0 && now - cameraCloudTokenIssuedAt < 3000000UL) {
    return true;
  }
  if (!strlen(AGRISENSE_FIREBASE_API_KEY)) return false;

  initCameraCloudTls();
  const String url = "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=" + String(AGRISENSE_FIREBASE_API_KEY);
  if (!cameraCloudHttpClient.begin(cameraCloudTlsClient, url)) return false;
  cameraCloudHttpClient.addHeader("Content-Type", "application/json");

  const int code = cameraCloudHttpClient.POST("{\"returnSecureToken\":true}");
  if (code == 200) {
    const String body = cameraCloudHttpClient.getString();
    const String token = jsonStringField(body, "idToken");
    if (token.length() > 0) {
      cameraCloudToken = token;
      cameraCloudTokenIssuedAt = now;
      cameraCloudHttpClient.end();
      return true;
    }
  } else {
    Serial.printf("Firebase camera auth POST failed (%d).\n", code);
  }
  cameraCloudHttpClient.end();
  return false;
}

static bool fulfillSnapshotRequest(const String &reqId) {
  if (reqId.length() == 0) return false;
  CameraAccess access;
  if (!access.ready()) return false;

  camera_fb_t *fb = esp_camera_fb_get();
  if (fb) { esp_camera_fb_return(fb); }
  fb = esp_camera_fb_get();
  if (!fb || fb->format != PIXFORMAT_JPEG || fb->len == 0) {
    if (fb) esp_camera_fb_return(fb);
    return false;
  }

  size_t outputLen = 0;
  mbedtls_base64_encode(nullptr, 0, &outputLen, fb->buf, fb->len);
  if (outputLen == 0 || outputLen > 65536) {
    esp_camera_fb_return(fb);
    return false;
  }

  unsigned char *encoded = (unsigned char *)malloc(outputLen + 1);
  if (!encoded) {
    esp_camera_fb_return(fb);
    return false;
  }

  size_t actualLen = 0;
  if (mbedtls_base64_encode(encoded, outputLen + 1, &actualLen, fb->buf, fb->len) != 0) {
    free(encoded);
    esp_camera_fb_return(fb);
    return false;
  }
  encoded[actualLen] = '\0';
  esp_camera_fb_return(fb);

  bool uploaded = false;
  if (ensureCameraCloudToken()) {
    initCameraCloudTls();
    const String url = String(AGRISENSE_FIREBASE_URL) + "/kits/demo/camera/snapshot.json?auth=" + cameraCloudToken;
    if (cameraCloudHttpClient.begin(cameraCloudTlsClient, url)) {
      cameraCloudHttpClient.addHeader("Content-Type", "application/json");
      String payload = "{\"version\":1,\"device_id\":\"" + demoDeviceId() +
        "\",\"request_id\":\"" + reqId + "\",\"jpeg_b64\":\"";
      payload += (char *)encoded;
      payload += "\"}";
      const int code = cameraCloudHttpClient.PUT(payload);
      if (code == 200) {
        uploaded = true;
      } else {
        if (code == 401 || code == 403) cameraCloudToken = "";
        Serial.printf("Firebase camera snapshot PUT failed (%d).\n", code);
      }
      cameraCloudHttpClient.end();
    }
  }
  free(encoded);
  return uploaded;
}

static void tickFirebaseCameraSync() {
  if (!strlen(AGRISENSE_FIREBASE_URL) || !strlen(AGRISENSE_FIREBASE_API_KEY)) return;
  if (!network.online() || network.connecting() || !demoCameraReady) return;

  const uint32_t now = millis();
  const bool identityDue = (now - lastCameraIdentityPush >= 10000);
  const bool requestDue = (now - lastCameraRequestPoll >= 1500);

  if (!identityDue && !requestDue) return;

  // Run at most ONE HTTP request per tick pass
  if (identityDue && (cameraCloudTaskTurn == 0 || !requestDue)) {
    cameraCloudTaskTurn = 1;
    lastCameraIdentityPush = now;
    if (ensureCameraCloudToken()) {
      initCameraCloudTls();
      const String url = String(AGRISENSE_FIREBASE_URL) + "/kits/demo/camera/identity.json?auth=" + cameraCloudToken;
      if (cameraCloudHttpClient.begin(cameraCloudTlsClient, url)) {
        cameraCloudHttpClient.addHeader("Content-Type", "application/json");
        const String payload = "{\"version\":1,\"kit_id\":\"" + String(AGRISENSE_KIT_ID) +
          "\",\"device_id\":\"" + demoDeviceId() + "\",\"role\":\"camera\",\"ready\":" +
          (demoCameraReady ? "true" : "false") + ",\"capabilities\":[\"capture\",\"stream\"],\"uploaded_at_ms\":{\".sv\":\"timestamp\"}}";
        const int code = cameraCloudHttpClient.PUT(payload);
        if (code != 200) {
          if (code == 401 || code == 403) cameraCloudToken = "";
          Serial.printf("Firebase camera identity PUT failed (%d).\n", code);
        }
        cameraCloudHttpClient.end();
      }
    }
    return;
  }

  if (requestDue) {
    cameraCloudTaskTurn = 0;
    lastCameraRequestPoll = now;
    if (ensureCameraCloudToken()) {
      initCameraCloudTls();
      cameraRequestDeduplicator.setDeviceId(demoDeviceId());
      const String url = String(AGRISENSE_FIREBASE_URL) + "/kits/demo/camera/request.json?auth=" + cameraCloudToken;
      if (cameraCloudHttpClient.begin(cameraCloudTlsClient, url)) {
        const int code = cameraCloudHttpClient.GET();
        if (code == 200) {
          const String body = cameraCloudHttpClient.getString();
          const String reqId = jsonStringField(body, "request_id");
          const String targetDevice = jsonStringField(body, "device_id");
          if (!cameraRequestDeduplicator.isBootSeeded()) {
            cameraRequestDeduplicator.seed(reqId);
          } else if (cameraRequestDeduplicator.shouldExecute(targetDevice, reqId)) {
            if (fulfillSnapshotRequest(reqId)) {
              cameraRequestDeduplicator.markExecuted(reqId);
            }
          }
        } else {
          if (code == 401 || code == 403) cameraCloudToken = "";
          Serial.printf("Firebase camera request GET failed (%d).\n", code);
        }
        cameraCloudHttpClient.end();
      }
    }
  }
}

#else

static inline void tickFirebaseCameraSync() {}

#endif
