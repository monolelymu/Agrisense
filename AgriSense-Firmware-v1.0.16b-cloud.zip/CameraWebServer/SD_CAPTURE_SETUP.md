# Optional camera SD

Use ../README.md for current setup and testing. The built-in AI Thinker slot
uses one-bit SD_MMC mode. A missing or failed card does not prevent app /capture.
This firmware never formats a card. Keep power off when inserting/removing it.

Successful JPEG /capture requests can save copies under
/captures/<random-session>/<sequence>.jpg. Streaming does not archive frames.
Existing files are not overwritten or automatically deleted. Card failures/full
storage disable archiving until restart; app capture remains available.

The legacy authenticated /auto-capture endpoint still needs working SD. Review
old sensor-board automation before the app-driven demo to prevent duplicate photos.
Serial diagnostics are optional for troubleshooting, not normal app connection.
