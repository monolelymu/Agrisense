#pragma once

#include "SD_MMC.h"
#include "esp_system.h"

// Only the capture HTTP task writes files. Streaming does not archive frames.
static bool captureStorageReady = false;
static char captureDirectory[32];
static uint32_t captureNumber = 0;

static void beginCaptureStorage() {
#if defined(CAMERA_MODEL_AI_THINKER)
  // One-bit mode avoids using GPIO4, which also drives the flash LED.
  // Never format a card automatically.
  if (!SD_MMC.begin("/sdcard", true, false)) {
    Serial.println("SD: unavailable; Wi-Fi captures remain enabled.");
    return;
  }
  if (!SD_MMC.exists("/captures") && !SD_MMC.mkdir("/captures")) {
    Serial.println("SD: cannot create captures folder; restart after checking card.");
    return;
  }
  // A fresh directory per boot prevents overwriting earlier captures.
  for (int attempt = 0; attempt < 8; ++attempt) {
    snprintf(captureDirectory, sizeof(captureDirectory), "/captures/%08lx", (unsigned long)esp_random());
    if (!SD_MMC.exists(captureDirectory) && SD_MMC.mkdir(captureDirectory)) {
      captureStorageReady = true;
      Serial.printf("SD: saving JPEG captures in %s\n", captureDirectory);
      return;
    }
  }
  Serial.println("SD: cannot create session folder; Wi-Fi captures remain enabled.");
#else
  Serial.println("SD: built-in slot support is configured for AI Thinker only.");
#endif
}

static bool saveCaptureCopy(const uint8_t *data, size_t length) {
  if (!captureStorageReady) return false;
  const uint64_t total = SD_MMC.totalBytes();
  const uint64_t used = SD_MMC.usedBytes();
  // Leave room for filesystem metadata. Never delete old photos automatically.
  if (used >= total || total - used < (uint64_t)length + 65536) {
    captureStorageReady = false;
    Serial.println("SD: full; saving disabled until restart. Wi-Fi captures remain enabled.");
    return false;
  }
  char path[64];
  snprintf(path, sizeof(path), "%s/%010lu.jpg", captureDirectory, (unsigned long)++captureNumber);
  if (SD_MMC.exists(path)) {
    captureStorageReady = false;
    Serial.println("SD: filename collision; saving disabled until restart.");
    return false;
  }
  File photo = SD_MMC.open(path, FILE_WRITE);
  if (!photo) {
    captureStorageReady = false;
    Serial.println("SD: cannot open photo; saving disabled until restart.");
    return false;
  }
  const size_t written = photo.write(data, length);
  photo.flush();
  const bool complete = written == length && photo.size() == length;
  photo.close();
  if (!complete) {
    SD_MMC.remove(path);  // Remove only this incomplete new photo.
    captureStorageReady = false;
    Serial.println("SD: write failed; saving disabled until restart. Check card.");
    return false;
  }
  Serial.printf("SD: saved %s (%u bytes)\n", path, (unsigned int)length);
  return true;
}
