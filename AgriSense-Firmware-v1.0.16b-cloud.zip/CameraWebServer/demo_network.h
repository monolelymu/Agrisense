#pragma once
#include <WiFi.h>
#include <ESPmDNS.h>
#include <esp_system.h>
#if !defined(AGRISENSE_WIFI_SSID) && __has_include("secrets.h")
#include "secrets.h"
#endif
#ifndef AGRISENSE_WIFI_SSID
#define AGRISENSE_WIFI_SSID ""
#endif
#ifndef AGRISENSE_WIFI_PASSWORD
#define AGRISENSE_WIFI_PASSWORD ""
#endif
#ifndef AGRISENSE_KIT_ID
#define AGRISENSE_KIT_ID "agrisense-demo-kit"
#endif
#ifndef AGRISENSE_FIREBASE_URL
#define AGRISENSE_FIREBASE_URL "https://agrisense-3eba5-default-rtdb.asia-southeast1.firebasedatabase.app"
#endif
#ifndef AGRISENSE_FIREBASE_API_KEY
#define AGRISENSE_FIREBASE_API_KEY "AIzaSyCdXw00WR8x2TYnse4NJAs2O2_pQ0QYA0c"
#endif

// Keep the copy in the other standalone sketch identical.
static String demoDeviceId() {
  const uint64_t mac = ESP.getEfuseMac();
  char id[13];
  snprintf(id, sizeof(id), "%04x%08lx", (unsigned int)(mac >> 32), (unsigned long)(mac & 0xffffffff));
  return String(id);
}
static String demoIdentity(const char *role, bool ready, const char *capabilities, const String &crop = "") {
  return String("{\"version\":1,\"kit_id\":\"") + AGRISENSE_KIT_ID +
    "\",\"device_id\":\"" + demoDeviceId() + "\",\"role\":\"" + role +
    "\",\"ready\":" + (ready ? "true" : "false") + ",\"capabilities\":" + capabilities +
    (crop.length() ? ",\"sensor_crop\":\"" + crop + "\"" : "") + "}";
}

class DemoNetwork {
 public:
  explicit DemoNetwork(const char *role) : role_(role) {}
  void begin() {
    host_ = String("agrisense-") + role_ + "-" + demoDeviceId().substring(6);
    WiFi.setHostname(host_.c_str());
    WiFi.onEvent([](WiFiEvent_t, WiFiEventInfo_t info) {
      Serial.printf("Wi-Fi disconnected, reason %u.\n", info.wifi_sta_disconnected.reason);
    }, ARDUINO_EVENT_WIFI_STA_DISCONNECTED);
    WiFi.mode(WIFI_STA);
    WiFi.setAutoReconnect(false); // Only this retry owner controls reconnects.
    WiFi.setSleep(false);
    Serial.printf("Reset reason %d; firmware 1.0.15d-power.\n", (int)esp_reset_reason());
    if (!strlen(AGRISENSE_WIFI_SSID)) Serial.println("Wi-Fi credentials are not configured in secrets.h.");
    // Enable the radio for pairing entropy, but defer association until setup settles.
    attemptedAt_ = millis();
  }
  bool connecting() const { return attempting_; }
  bool online() const {
    return WiFi.status() == WL_CONNECTED && WiFi.localIP() != IPAddress(0, 0, 0, 0);
  }
  void tick(bool allowConnect = true) {
    const uint32_t now = millis();
    if (online()) {
      attempting_ = false;
      if (!connected_ || address_ != WiFi.localIP()) {
        if (advertised_) MDNS.end();
        advertised_ = false;
        connected_ = true;
        address_ = WiFi.localIP();
        retry_ = 0;
        mdnsAt_ = now - 5000;
        Serial.println(String(role_) + " connected.");
      }
      if (!advertised_ && now - mdnsAt_ >= 5000) {
        mdnsAt_ = now;
        if (MDNS.begin(host_.c_str())) {
          MDNS.addService("agrisense", "tcp", 80);
          MDNS.addServiceTxt("agrisense", "tcp", "version", "1");
          MDNS.addServiceTxt("agrisense", "tcp", "kit_id", AGRISENSE_KIT_ID);
          MDNS.addServiceTxt("agrisense", "tcp", "role", role_);
          MDNS.addServiceTxt("agrisense", "tcp", "device_id", demoDeviceId().c_str());
          advertised_ = true;
        }
      }
      return;
    }
    if (connected_) {
      connected_ = false;
      if (advertised_) MDNS.end();
      advertised_ = false;
      retry_ = 0;
      // Stop the old association before another begin, including DHCP failures.
      attempting_ = true;
      attemptedAt_ = now - ATTEMPT_TIMEOUT_MS;
    }
    if (!strlen(AGRISENSE_WIFI_SSID)) return;
    static const uint32_t delays[] = {2000, 5000, 10000, 30000};
    if (attempting_) {
      if (now - attemptedAt_ < ATTEMPT_TIMEOUT_MS) return;
      // A successful stop cancels any in-flight scan/connect before retrying.
      // On stop failure stay in this state and try stopping again after one second.
      if (!WiFi.mode(WIFI_OFF)) {
        attemptedAt_ = now - ATTEMPT_TIMEOUT_MS + 1000;
        return;
      }
      attempting_ = false;
      radioStopped_ = true;
      attemptedAt_ = now;
      waitMs_ = delays[retry_];
      if (retry_ < 3) ++retry_;
      Serial.println("Wi-Fi attempt ended; radio resting before retry.");
      return;
    }
    if (!allowConnect || now - attemptedAt_ < waitMs_) return;
    if (radioStopped_) {
      WiFi.setHostname(host_.c_str());
      if (!WiFi.mode(WIFI_STA)) { attemptedAt_ = now; return; }
      WiFi.setAutoReconnect(false);
      WiFi.setSleep(false);
      radioStopped_ = false;
    }
    attemptedAt_ = millis();
    attempting_ = true;
    WiFi.begin(AGRISENSE_WIFI_SSID, AGRISENSE_WIFI_PASSWORD);
  }
 private:
  const char *role_;
  String host_;
  IPAddress address_;
  bool connected_ = false, advertised_ = false;
  static constexpr uint32_t ATTEMPT_TIMEOUT_MS = 20000;
  bool attempting_ = false, radioStopped_ = false;
  uint32_t waitMs_ = 2000;
  uint8_t retry_ = 0;
  uint32_t attemptedAt_ = 0, mdnsAt_ = 0;
};
