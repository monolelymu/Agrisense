#pragma once
// Copy to secrets.h in this folder. Keep secrets.h private.
// Only Wi-Fi credentials are required. Firebase URL and Web API Key have built-in defaults.
#define AGRISENSE_WIFI_SSID "YOUR_WIFI_SSID"
#define AGRISENSE_WIFI_PASSWORD "YOUR_WIFI_PASSWORD"

// Optional overrides (defaults are built into demo_network.h):
// #define AGRISENSE_KIT_ID "agrisense-demo-kit"
// #define AGRISENSE_FIREBASE_URL "https://agrisense-3eba5-default-rtdb.asia-southeast1.firebasedatabase.app"
// #define AGRISENSE_FIREBASE_API_KEY "AIzaSyCdXw00WR8x2TYnse4NJAs2O2_pQ0QYA0c"
