# AgriSense firmware v1.0.15d-power

Based on the exact v1.0.15 source archive; intended for the current AgriSense v1.0.15d app (build 20). These are SOURCE projects, not flashed or ESP32-compiled on this PC. Both sensor and camera source changed. The original AgriSense-Firmware-v1.0.15.zip is the rollback copy. Completed credentials are excluded from this package. RTC, both SD storage paths, timestamps, pairing and saved warnings are retained.

## Power-demand changes

- Wi-Fi association is deferred at least two seconds. Each attempt has a 20-second window, including address acquisition. Before any retry the radio must successfully stop, followed by a 2/5/10/30-second capped rest. There are no overlapping reconnect calls. Missing credentials do not start attempts. Reset and disconnect reason codes are logged without keys.
- Sensor RTC/SD initialization finishes before servo initialization. Pan is commanded first, tilt at least 750 ms later; controls become ready after another 750 ms. Failed attachment leaves movement unavailable.
- Only one axis advances at a time. Center completes pan first, waits 250 ms, then moves tilt. Commands are busy during movement/settling and active association. Duplicates still return the original receipt. Limits, step size, PWM and holding torque remain unchanged.
- Sensor association starts only while servos are idle. Sensor SD logging and board-triggered automatic captures defer during motion/settling; fresh sampling and warning evaluation continue. Deferred captures do not consume cooldown. Logging may be delayed and does not replay missed samples.
- Camera initialization retries wait for its current Wi-Fi attempt to finish. Initial camera/SD setup finishes before the first association starts. Resolution and live-view configuration are retained.

These changes reduce overlapping commanded loads; they do not regulate voltage or guarantee no brownouts. PWM holding current, ongoing Wi-Fi traffic, manual camera captures/live streaming and external loads can still overlap across boards. Keep the camera's separate power source that resolved the user's symptom and a suitable servo power branch with common ground. Brownout protection remains unchanged. Mechanical settling and current savings are unmeasured.

## Install

1. Keep the existing working ESP32 Arduino 3.x board package and Adafruit DHT, Unified Sensor and RTClib libraries. No new library is needed.
2. Copy secrets.example.h to secrets.h inside the sensor sketch and enter the kit Wi-Fi privately. Keep the kit ID agrisense-demo-kit. Preserve the working camera settings.
3. Open sensor_node_full/sensor_node_full.ino. Select the same ESP32 Dev Module (WROOM) and port used for your working sensor board. Verify/compile, then upload. Keep Erase All Flash disabled to preserve crop, pairing and saved rules. SD remains optional.
4. Compile and upload BOTH sketches for these power-demand changes. The existing AI Thinker ESP32-CAM configuration and camera-driver requirements still apply. Retain each board's private Wi-Fi/kit settings and keep Erase All Flash disabled on both boards.
5. Use the existing v1.0.15d app, join the kit Wi-Fi and tap Connect/Retry connection. Open sensor-alert settings, save limits, and confirm Saved to kit. A sensor pairing code is needed for authenticated rule changes; use the existing Device setup flow. Keys are never printed by this update.

## Sampling and logging

Soil and MQ135 raw ADC readings update approximately every second. DHT22 temperature/humidity update every two seconds, with their own freshness timestamp. Invalid DHT readings are unavailable. Serial and SD logging stay at ten seconds. Existing blocking SD, camera-automation or network operations can delay these targets.

The app checks every second without overlapping monitoring requests. Camera movement/capture take priority. Live readings update immediately; ten-second trend persistence preserves the useful history window.

## Moderate servo preset

Signal pins remain pan GPIO25 and tilt GPIO26. Targets remain 75..105 degrees, center 90, with ten degrees per command and two-degree increments every 20ms. Increments clamp to the target, including odd angles. PWM remains 50Hz, 16-bit, using the existing 1000..2000us mapping. Nominal software speed is 100 degrees/second; physical speed is not measured.

Both servos need the existing suitable regulated 5V supply and common ground with the sensor ESP32. Do not power them from the ESP32 3.3V pin. Center with the linkage loosened before first physical testing. Stop if the mount binds, buzzes or the board resets. Reverse PAN_SIGN/TILT_SIGN if needed after checking direction. No travel-limit increase is included. Acknowledgement confirms command acceptance, not shaft position.

## Exactly three warning LEDs

Connect each through its own existing 330-ohm resistor to LED anode; cathode to GND. No LED GPIO should be connected to 5V.

| LED | GPIO | Meaning when lit |
|---|---:|---|
| Temperature/humidity | 14 | Either enabled valid reading is outside its saved range |
| Soil | 27 | Raw or calibrated soil reading is outside its saved range |
| Gas | 33 | Raw gas reading is outside its enabled saved range |

GPIO17, GPIO4 and GPIO13 are no longer configured as LED outputs. No hardware additions are required for the three existing sensor LEDs.

Limits saved by AgriSense persist on the sensor board. Warnings continue with the app closed, without Wi-Fi, and after restart. LEDs react on the next valid sample; photo-alert duration and cooldown are separate. Disabled/unconfigured/invalid measurements and readings older than five seconds cannot light an LED. An unlit LED does not prove sensor health.

Gas warnings default disabled, use 0..4095 raw units, and do not represent ppm, air safety, or a phone/photo alert. Soil percentage warnings require actual calibration; the existing raw soil mode works without a fabricated percentage. Changing the physical board crop clears old warning limits until new settings are acknowledged.

## Your physical verification

Host tests exercise scheduling and protocol logic with shims, not ESP32 drivers. ESP32 compilation, upload and physical acceptance remain required. No new libraries are needed. See the delivered release notes for commands/results.

Test cold startup, missing/slow Wi-Fi, router restart, Center from both axes displaced, rapid/duplicate commands, still capture and live view, SD logging timestamps, standalone automatic photos, offline warning LEDs and saved settings after restart. Measure board input and 3.3 V rails during the worst combined load. Check logs for reset reasons or repeated disconnects. Do not interpret successful host tests as power validation.

Rollback: compile/upload both original sketch folders from AgriSense-Firmware-v1.0.15.zip with your private settings, retaining flash/NVS. No storage format or app change is needed.

1. Confirm new readings, camera still capture and existing live view.
2. Move the unloaded mount each direction, then Center. Check direction, clearance, supply stability and no unexpected repeat movement.
3. Save deliberately inside/outside limits and verify each LED, including humidity alone for the shared DHT LED. Restore suitable limits afterward.
4. Close AgriSense, disconnect phone Wi-Fi, then restart the sensor: board warnings must continue from saved settings after fresh measurements arrive.
5. Test kit reconnection, failed DHT reads and optional SD logging. Do not infer a disconnected analog probe from its ADC value alone.

## Software verification

Host C++ checks cover bounded movement, duplicate/stale rejection, three warning LEDs, five-second expiry, invalid readings, offline warnings, authenticated warning configuration, range/unit validation, idempotent saves, saved-limit restore, crop clearing and storage failure. They use test shims, not the ESP32 driver. ESP32 compilation, actual board HTTP behavior, electrical wiring and mechanical movement remain for your hardware checks. No new dependencies are required.
