#include <cassert>
#include <cmath>
#include <iostream>
#include <vector>
#include "esp32-hal-ledc.h"
#include "../sensor_node_full/firebase_sync.h"

// Structural JSON brace/bracket/quote balance and key-depth verifier for host tests.
static bool verifyBalancedJson(const std::string &s) {
  if (s.empty() || s.front() != '{' || s.back() != '}') return false;
  std::vector<char> stack;
  bool inQuotes = false;
  for (size_t i = 0; i < s.size(); ++i) {
    char c = s[i];
    if (c == '"' && (i == 0 || s[i - 1] != '\\')) {
      inQuotes = !inQuotes;
      continue;
    }
    if (inQuotes) continue;
    if (c == '{' || c == '[') {
      stack.push_back(c);
    } else if (c == '}') {
      if (stack.empty() || stack.back() != '{') return false;
      stack.pop_back();
      if (stack.empty() && i + 1 != s.size()) return false;
    } else if (c == ']') {
      if (stack.empty() || stack.back() != '[') return false;
      stack.pop_back();
    }
  }
  return !inQuotes && stack.empty();
}

// Returns the brace depth at the start of a substring outside quotes, or -1 if not found.
static int keyBraceDepth(const std::string &s, const std::string &needle) {
  auto pos = s.find(needle);
  if (pos == std::string::npos) return -1;
  int braceDepth = 0;
  bool inQuotes = false;
  for (size_t i = 0; i < pos; ++i) {
    char c = s[i];
    if (c == '"' && (i == 0 || s[i - 1] != '\\')) {
      inQuotes = !inQuotes;
      continue;
    }
    if (inQuotes) continue;
    if (c == '{') ++braceDepth;
    else if (c == '}') --braceDepth;
  }
  return inQuotes ? -1 : braceDepth;
}

int main() {
  std::cout << "Testing jsonStringField..." << std::endl;
  {
    String json = "{\"version\":1,\"device_id\":\"001122334455\",\"request_id\":\"req-abc-123\",\"action\":\"left\"}";
    assert(jsonStringField(json, "device_id") == "001122334455");
    assert(jsonStringField(json, "request_id") == "req-abc-123");
    assert(jsonStringField(json, "action") == "left");
    assert(jsonStringField(json, "nonexistent") == "");
    assert(jsonStringField(json, "version") == ""); // integer, not a string

    String fbJson = "{\"device_id\": \"aabbcc\", \"action\": \"right\", \"request_id\": \"req-999\"}";
    assert(jsonStringField(fbJson, "device_id") == "aabbcc");
    assert(jsonStringField(fbJson, "action") == "right");
    assert(jsonStringField(fbJson, "request_id") == "req-999");
  }

  std::cout << "Testing actual firmware sensor payload builder (buildOpenReadingsJson & buildSensorCloudPayload)..." << std::endl;
  {
    const String identity = "{\"version\":1,\"kit_id\":\"agrisense-demo-kit\",\"device_id\":\"aabbccddeeff\",\"role\":\"sensor\",\"ready\":true,\"capabilities\":[\"readings\",\"sd_optional\",\"pan_tilt_v1\",\"app_status_v1\",\"warning_leds_v1\"],\"sensor_crop\":\"tomato\"}";
    const String openReadings = buildOpenReadingsJson(
      "aabbccddeeff", "tomato", "boot01", 42UL,
      26.5f, 65.0f, 2100, true, 45, 750);

    // openReadings intentionally leaves the object open for age fields:
    assert(!verifyBalancedJson(openReadings.value));

    // closeReadingsJson closes it into valid JSON for local /readings:
    const String localReadings = closeReadingsJson(openReadings, 250UL, 120UL);
    assert(verifyBalancedJson(localReadings.value));

    // buildSensorCloudPayload builds the full /kits/demo/sensor.json document:
    const String cloudPayload = buildSensorCloudPayload(identity, openReadings, 250UL, 120UL);
    assert(verifyBalancedJson(cloudPayload.value));

    // Verify exact expected string structure:
    const String expected =
      "{\"identity\":{\"version\":1,\"kit_id\":\"agrisense-demo-kit\",\"device_id\":\"aabbccddeeff\",\"role\":\"sensor\",\"ready\":true,\"capabilities\":[\"readings\",\"sd_optional\",\"pan_tilt_v1\",\"app_status_v1\",\"warning_leds_v1\"],\"sensor_crop\":\"tomato\"}"
      ",\"readings\":{\"version\":1,\"device_id\":\"aabbccddeeff\",\"crop\":\"tomato\",\"sample_id\":\"boot01-42\",\"temp_c\":26.5,\"humidity_pct\":65.0,\"soil_raw\":2100,\"soil_pct\":45,\"soil_calibrated\":true,\"gas_raw\":750,\"dht_age_ms\":250,\"age_ms\":120}"
      ",\"uploaded_at_ms\":{\".sv\":\"timestamp\"}}";
    assert(cloudPayload == expected);

    // Verify key depths: identity, readings, and uploaded_at_ms MUST be at root depth (depth 1),
    // while sensor fields (sample_id, dht_age_ms, age_ms) MUST be inside readings (depth 2).
    assert(keyBraceDepth(cloudPayload.value, "\"identity\":") == 1);
    assert(keyBraceDepth(cloudPayload.value, "\"readings\":") == 1);
    assert(keyBraceDepth(cloudPayload.value, "\"uploaded_at_ms\":") == 1);
    assert(keyBraceDepth(cloudPayload.value, "\".sv\":\"timestamp\"") == 2);
    assert(keyBraceDepth(cloudPayload.value, "\"sample_id\":\"boot01-42\"") == 2);
    assert(keyBraceDepth(cloudPayload.value, "\"dht_age_ms\":250") == 2);
    assert(keyBraceDepth(cloudPayload.value, "\"age_ms\":120") == 2);

    // Also test uncalibrated soil and failed/NAN DHT readings:
    const String openNullReadings = buildOpenReadingsJson(
      "aabbccddeeff", "tomato", "boot01", 43UL,
      NAN, NAN, 3000, false, 0, 500);
    const String nullCloudPayload = buildSensorCloudPayload(identity, openNullReadings, 60000UL, 50UL);
    assert(verifyBalancedJson(nullCloudPayload.value));
    assert(nullCloudPayload.indexOf("\"temp_c\":null") >= 0);
    assert(nullCloudPayload.indexOf("\"humidity_pct\":null") >= 0);
    assert(nullCloudPayload.indexOf("\"soil_pct\":null") >= 0);
    assert(nullCloudPayload.indexOf("\"soil_calibrated\":false") >= 0);
    assert(keyBraceDepth(nullCloudPayload.value, "\"uploaded_at_ms\":") == 1);
  }

  std::cout << "Testing CloudDeduplicator boot-seeding and replay protection..." << std::endl;
  {
    CloudDeduplicator dedup("dev-sensor-01");
    assert(!dedup.isBootSeeded());
    assert(dedup.getLastRequestId() == "");

    // 1. Before boot seeding, commands MUST NOT execute
    assert(!dedup.shouldExecute("dev-sensor-01", "old-cmd-1"));

    // 2. Simulate failed initial poll: remains unseeded
    assert(!dedup.isBootSeeded());
    assert(!dedup.shouldExecute("dev-sensor-01", "old-cmd-1"));

    // 3. First successful poll reads pre-existing command sitting in Firebase
    dedup.seed("old-cmd-1");
    assert(dedup.isBootSeeded());
    assert(dedup.getLastRequestId() == "old-cmd-1");

    // Pre-existing command must be rejected (no replay on reboot!)
    assert(!dedup.shouldExecute("dev-sensor-01", "old-cmd-1"));

    // 4. New command arriving after boot must execute
    assert(dedup.shouldExecute("dev-sensor-01", "new-cmd-2"));
    dedup.markExecuted("new-cmd-2");
    assert(dedup.getLastRequestId() == "new-cmd-2");

    // 5. Duplicate poll with same command must NOT re-execute
    assert(!dedup.shouldExecute("dev-sensor-01", "new-cmd-2"));

    // 6. Command for different device must NOT execute
    assert(!dedup.shouldExecute("other-sensor-99", "new-cmd-3"));

    // 7. Empty request ID must NOT execute
    assert(!dedup.shouldExecute("dev-sensor-01", ""));

    // 8. Next valid command executes
    assert(dedup.shouldExecute("dev-sensor-01", "new-cmd-3"));
    dedup.markExecuted("new-cmd-3");
    assert(dedup.getLastRequestId() == "new-cmd-3");
  }

  std::cout << "Testing CloudDeduplicator with empty/null initial node..." << std::endl;
  {
    CloudDeduplicator dedup("dev-cam-01");
    dedup.seed("");
    assert(dedup.isBootSeeded());
    assert(dedup.getLastRequestId() == "");

    assert(dedup.shouldExecute("dev-cam-01", "snap-req-1"));
    dedup.markExecuted("snap-req-1");
    assert(!dedup.shouldExecute("dev-cam-01", "snap-req-1"));
  }

  std::cout << "All cloud sync host checks passed!" << std::endl;
  return 0;
}
