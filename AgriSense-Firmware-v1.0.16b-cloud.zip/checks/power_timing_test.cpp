#include "../sensor_node_full/auto_capture_timing.h"
#include <cassert>
#include <iostream>
int main() {
  AutoCaptureTiming timing;
  bool selected[] = {true, false, false};
  float values[] = {35, NAN, NAN}, low[] = {20, 40, 20}, high[] = {30, 80, 80};
  timing.reset(0);
  for (uint32_t now = 0; now <= 60000; now += 1000)
    assert(!timing.update(now, values, selected, low, high, 10, 60, false));
  assert(timing.lastAttempt == 0); // Deferral must not consume the cooldown.
  assert(timing.update(61000, values, selected, low, high, 10, 60, true));
  assert(!timing.update(62000, values, selected, low, high, 10, 60, true));
  values[0] = NAN;
  assert(!timing.update(63000, values, selected, low, high, 10, 60, false));
  assert(!timing.active[0]); // Invalid samples still reset duration while moving.
  values[0] = 35;
  assert(!timing.update(120000, values, selected, low, high, 10, 60, true)); // Gap resets duration.
  assert(timing.update(130000, values, selected, low, high, 10, 60, true));
  timing.reset(UINT32_MAX - 30000);
  for (uint32_t elapsed = 0; elapsed < 60000; elapsed += 10000)
    assert(!timing.update(uint32_t(UINT32_MAX - 30000 + elapsed), values, selected, low, high, 10, 60));
  assert(timing.update(uint32_t(UINT32_MAX - 30000 + 60000), values, selected, low, high, 10, 60));
  std::cout << "PASS: capture deferral preserves duration/freshness and cooldown\n";
}
