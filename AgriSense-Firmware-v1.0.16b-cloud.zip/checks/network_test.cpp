#ifdef NETWORK_EMPTY_TEST
#define AGRISENSE_WIFI_SSID ""
#else
#define AGRISENSE_WIFI_SSID "host-test-only"
#endif
#define AGRISENSE_WIFI_PASSWORD ""
#include "../sensor_node_full/demo_network.h"
#include <iostream>

int main() {
  WiFi.state = 0;
  DemoNetwork network("sensor");
  network.begin();
#ifdef NETWORK_EMPTY_TEST
  for (testMillis = 0; testMillis < 300000; testMillis += 1000) network.tick();
  assert(WiFi.begins == 0 && WiFi.stops == 0 && !network.connecting());
  std::cout << "PASS: missing credentials never start a connection\n";
  return 0;
#endif
  testMillis = 1999; network.tick(); assert(WiFi.begins == 0);
  testMillis = 2000; network.tick(false); assert(WiFi.begins == 0);
  network.tick(); assert(WiFi.begins == 1 && network.connecting());
  testMillis = 21999; network.tick(); assert(WiFi.begins == 1 && WiFi.stops == 0);
  // A failed stop must never launch another connection request.
  WiFi.stopOk = false;
  testMillis = 22000; network.tick(); assert(WiFi.stops == 1 && network.connecting());
  testMillis = 22999; network.tick(); assert(WiFi.stops == 1);
  WiFi.stopOk = true;
  testMillis = 23000; network.tick(); assert(!network.connecting() && WiFi.stops == 2);
  testMillis = 24999; network.tick(); assert(WiFi.begins == 1);
  testMillis = 25000; network.tick(); assert(WiFi.begins == 2);
  // Association without DHCP remains a bounded attempt.
  WiFi.state = WL_CONNECTED;
  testMillis = 45000; network.tick(); assert(!network.connecting() && WiFi.begins == 2);
  testMillis = 49999; network.tick(); assert(WiFi.begins == 2);
  testMillis = 50000; network.tick(); assert(WiFi.begins == 3);
  WiFi.state = WL_CONNECTED; WiFi.ip = IPAddress(192,168,1,2);
  network.tick(); assert(network.online() && !network.connecting() && MDNS.adverts == 1);
  WiFi.state = 0; WiFi.ip = {};
  network.tick(); assert(MDNS.ends == 1 && !network.connecting());
  // Successful connection resets the backoff to two seconds.
  testMillis += 1999; network.tick(); assert(WiFi.begins == 3);
  testMillis += 1; network.tick(); assert(WiFi.begins == 4);
  // Deadlines remain correct across millis rollover.
  WiFi.state = 0; testMillis = UINT32_MAX - 1000;
  DemoNetwork wrapped("camera"); wrapped.begin();
  testMillis = 998; wrapped.tick(); assert(WiFi.begins == 4);
  testMillis = 999; wrapped.tick(); assert(WiFi.begins == 5);
  // Escalating backoff is capped; a failed radio start cannot launch begin.
  for (const uint32_t wait : {2000u, 5000u, 10000u, 30000u, 30000u}) {
    testMillis += 20000; wrapped.tick(); assert(!wrapped.connecting());
    const int attempts = WiFi.begins;
    testMillis += wait - 1; wrapped.tick(); assert(WiFi.begins == attempts);
    testMillis += 1;
    WiFi.startOk = false; wrapped.tick(); assert(WiFi.begins == attempts);
    WiFi.startOk = true;
    testMillis += wait; wrapped.tick(); assert(WiFi.begins == attempts + 1);
  }
  assert(demoIdentity("sensor", true, "[]").length() > 0);
  std::cout << "PASS: bounded Wi-Fi attempts, stop failure, DHCP timeout, backoff, movement deferral, discovery, rollover\n";
}
