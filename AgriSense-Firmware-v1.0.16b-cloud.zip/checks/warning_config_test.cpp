#include "esp32-hal-ledc.h"
#include <cstring>
#include <vector>
#include <iostream>
#include <cmath>
String sensorCrop = "tomato";
const bool SOIL_CALIBRATED = false;
const int DRY_VALUE = 3000, WET_VALUE = 1200;
size_t strlcpy(char *dest, const char *source, size_t size) {
  const size_t length = strlen(source);
  if (size) { const size_t count = std::min(size - 1, length); memcpy(dest, source, count); dest[count] = 0; }
  return length;
}
struct FakePreferences {
  std::vector<unsigned char> stored;
  bool fail = false;
  int writes = 0;
  size_t putBytes(const char *, const void *value, size_t size) {
    if (fail) return 0;
    writes++; stored.assign((const unsigned char *)value, (const unsigned char *)value + size); return size;
  }
  size_t getBytes(const char *, void *value, size_t size) {
    if (stored.size() != size) return 0;
    memcpy(value, stored.data(), size); return size;
  }
  size_t getBytesLength(const char *) { return stored.size(); }
} preferences;
bool paired = true;
bool authorizeAutomatic() { if (!paired) server.send(401, "application/json", "denied"); return paired; }
bool autoNumber(const String &text, float &value) {
  if (!text.length() || text.length() > 12) return false;
  char *end; value = strtof(text.c_str(), &end);
  return *end == 0 && std::isfinite(value);
}
#include "../sensor_node_full/warning_config.h"

void request() {
  server.fields = {{"version", "1"}, {"device_id", deviceId}, {"crop", "tomato"}, {"soil_raw", "1"}};
  const char *names[] = {"temp", "humidity", "soil", "gas"};
  for (int i = 0; i < 4; i++) {
    server.fields[std::string(names[i]) + "_enabled"] = "1";
    server.fields[std::string(names[i]) + "_min"] = i == 0 ? "18" : "0";
    server.fields[std::string(names[i]) + "_max"] = i == 0 ? "30" : i == 1 ? "80" : "3000";
  }
}
int main() {
  serveWarnings(); assert(server.response.value.find("\"configured\":false") != std::string::npos);
  request(); paired = false; changeWarnings(); assert(server.status == 401 && preferences.writes == 0);
  paired = true; server.fields["device_id"] = "wrong"; changeWarnings(); assert(server.status == 409);
  request(); server.fields["crop"] = "chili"; changeWarnings(); assert(server.status == 409);
  request(); server.fields["gas_max"] = "4096"; changeWarnings(); assert(server.status == 400);
  request(); server.fields["gas_min"] = "nan"; changeWarnings(); assert(server.status == 400);
  request(); server.fields["soil_raw"] = "0"; server.fields["soil_max"] = "100";
  changeWarnings(); assert(server.status == 400); // No calibrated percentage on this board.
  request(); changeWarnings(); assert(server.status == 200 && preferences.writes == 1);
  changeWarnings(); assert(preferences.writes == 1); // Retry does not wear flash.
  warningConfig = WarningConfig{}; loadWarnings(); assert(warningConfig.configured && warningConfig.selected[3]);
  assert(warningConfig.maximum[3] == 3000); // Restore after reboot without phone.
  assert(clearWarnings()); sensorCrop = "chili"; warningConfig = WarningConfig{}; loadWarnings();
  assert(!warningConfig.configured); // Crop reassignment cannot resurrect old limits.
  sensorCrop = "tomato"; request(); preferences.fail = true; changeWarnings();
  assert(server.status == 503 && !configurationReady && !warningConfig.configured);
  std::cout << "PASS: authenticated warnings, device/crop/unit validation, gas bounds, idempotent saves, restart restore, crop clearing, storage failure\n";
}
