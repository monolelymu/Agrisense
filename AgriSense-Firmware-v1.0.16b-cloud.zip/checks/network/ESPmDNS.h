#pragma once
inline struct FakeMDNS {
  int adverts = 0, ends = 0;
  bool begin(const char *) { ++adverts; return true; }
  void end() { ++ends; }
  void addService(const char *, const char *, int) {}
  void addServiceTxt(const char *, const char *, const char *, const char *) {}
} MDNS;
