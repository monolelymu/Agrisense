#pragma once
#include "../esp32-hal-ledc.h"
#include <cstring>
#include <cstdio>
inline struct FakeSerial {
  void println(const String &) {}
  template<class... Args> void printf(const char *, Args...) {}
} Serial;
