#pragma once
#include <cstdint>
inline struct FakeESP { uint64_t getEfuseMac() const { return 0xaabbccddeeffULL; } } ESP;
inline int esp_reset_reason() { return 1; }
